<?php
/**
 * Journal Interface Template
 * 
 * Main template for the journal interface including grid view,
 * entry editor, and navigation elements.
 */

// Prevent direct access
if (!defined('ABSPATH')) exit;
?>

<?php if (!is_user_logged_in()): ?>
    <div class="journal-login-container">
        <div class="journal-login">
            <h2><?php _e('Welcome to Your 30-Day Journal', 'guided-journal'); ?></h2>
            <p><?php _e('Sign in with your Circle Community account to start your journaling journey.', 'guided-journal'); ?></p>
            
            <a href="<?php echo esc_url(Circle_SSO::get_login_url()); ?>" class="circle-login-button">
                <img src="<?php echo esc_url(JOURNAL_PLUGIN_URL . 'assets/images/circle-sso-button.png'); ?>" 
                     alt="<?php esc_attr_e('Circle SSO', 'guided-journal'); ?>">
                <?php _e('Sign in with Circle', 'guided-journal'); ?>
            </a>
            
            <div class="login-footer">
                <p class="privacy-notice">
                    <?php _e('Your entries are private by default and securely encrypted.', 'guided-journal'); ?>
                </p>
            </div>
        </div>
    </div>

<?php else: ?>
    <div class="journal-wrapper" data-user-id="<?php echo esc_attr(get_current_user_id()); ?>">
        <!-- Header Section -->
        <div class="header-image">
            <img src="<?php echo esc_url(JOURNAL_PLUGIN_URL . 'assets/images/header-image.jpg'); ?>" 
                 alt="<?php esc_attr_e('Journal Header', 'guided-journal'); ?>">
        </div>

        <div class="container">
            <!-- User Info & Navigation -->
            <div class="user-info">
                <div class="user-welcome">
                    <?php 
                    $user = wp_get_current_user();
                    printf(
                        __('Welcome, %s', 'guided-journal'),
                        '<span class="user-name">' . esc_html($user->display_name) . '</span>'
                    );
                    ?>
                    <div class="user-streak">
                        <?php 
                        $streak = get_user_meta($user->ID, 'journal_streak', true);
                        if ($streak > 0) {
                            printf(
                                __('🔥 %d day streak!', 'guided-journal'),
                                intval($streak)
                            );
                        }
                        ?>
                    </div>
                </div>
                <div class="user-nav">
                    <button class="view-progress-btn">
                        <?php _e('View Progress', 'guided-journal'); ?>
                    </button>
                    <a href="<?php echo esc_url(wp_logout_url(get_permalink())); ?>" class="logout-link">
                        <?php _e('Logout', 'guided-journal'); ?>
                    </a>
                </div>
            </div>

            <h1 class="journal-title"><?php _e('30-Day Guided Journal', 'guided-journal'); ?></h1>
            
            <!-- Grid View -->
            <div id="gridView" class="prompt-grid">
                <?php
                $completed_days = get_user_journal_progress($user->ID);
                $current_day = get_user_current_day($user->ID);
                
                for ($day = 1; $day <= 30; $day++):
                    $is_completed = in_array($day, $completed_days);
                    $is_current = $day === $current_day;
                    $is_locked = $day > $current_day;
                    
                    $classes = array('prompt-card');
                    if ($is_completed) $classes[] = 'completed';
                    if ($is_current) $classes[] = 'current';
                    if ($is_locked) $classes[] = 'locked';
                ?>
                    <div class="<?php echo esc_attr(implode(' ', $classes)); ?>" 
                         data-day="<?php echo esc_attr($day); ?>">
                        <div class="card-content">
                            <span class="day-number"><?php printf(__('Day %d', 'guided-journal'), $day); ?></span>
                            <?php if ($is_completed): ?>
                                <span class="completion-mark">✓</span>
                            <?php elseif ($is_locked): ?>
                                <span class="lock-icon">🔒</span>
                            <?php endif; ?>
                        </div>
                    </div>
                <?php endfor; ?>
            </div>
            
            <!-- Journal Entry View -->
            <div id="journalView" class="journal-container" style="display: none;">
                <div class="navigation-top">
                    <button class="contents-toggle">
                        <span class="icon">←</span>
                        <?php _e('Back to Grid', 'guided-journal'); ?>
                    </button>
                    <div class="sync-status"></div>
                </div>
                
                <h2 id="dayTitle"></h2>
                
                <div id="promptText" class="prompt"></div>
                
                <!-- Entry Controls -->
                <div class="entry-controls">
                    <div class="privacy-controls">
                        <label for="entryVisibility">
                            <?php _e('Entry Privacy:', 'guided-journal'); ?>
                            <div class="privacy-info">
                                <span class="info-icon">ℹ️</span>
                                <div class="privacy-tooltip">
                                    <?php _e('Private: Encrypted and only visible to you', 'guided-journal'); ?><br>
                                    <?php _e('Community: Visible to Circle members', 'guided-journal'); ?><br>
                                    <?php _e('Public: Visible to everyone', 'guided-journal'); ?>
                                </div>
                            </div>
                        </label>
                        <select id="entryVisibility">
                            <option value="private"><?php _e('Private (Only you)', 'guided-journal'); ?></option>
                            <option value="community"><?php _e('Community (Circle members)', 'guided-journal'); ?></option>
                            <option value="public"><?php _e('Public', 'guided-journal'); ?></option>
                        </select>
                    </div>
                    
                    <div class="writing-tools">
                        <button class="tool-button" data-tool="bold" title="<?php esc_attr_e('Bold', 'guided-journal'); ?>">
                            <span class="icon">B</span>
                        </button>
                        <button class="tool-button" data-tool="italic" title="<?php esc_attr_e('Italic', 'guided-journal'); ?>">
                            <span class="icon">I</span>
                        </button>
                        <button class="tool-button" data-tool="list" title="<?php esc_attr_e('List', 'guided-journal'); ?>">
                            <span class="icon">•</span>
                        </button>
                    </div>
                </div>
                
                <!-- Entry Editor -->
                <div class="editor-container">
                    <textarea id="journalEntry" placeholder="<?php esc_attr_e('Write your entry here...', 'guided-journal'); ?>"></textarea>
                    <div class="editor-footer">
                        <div class="word-count">
                            <?php _e('Words:', 'guided-journal'); ?> <span>0</span>
                        </div>
                        <div class="autosave-status"></div>
                    </div>
                </div>
                
                <!-- Entry Navigation -->
                <div class="navigation">
                    <button id="prevDay" class="nav-button">
                        <span class="icon">←</span>
                        <?php _e('Previous Day', 'guided-journal'); ?>
                    </button>
                    <button id="saveEntry" class="save-button" disabled>
                        <?php _e('Save Entry', 'guided-journal'); ?>
                    </button>
                    <button id="nextDay" class="nav-button">
                        <?php _e('Next Day', 'guided-journal'); ?>
                        <span class="icon">→</span>
                    </button>
                </div>
                
                <!-- Entry Metadata -->
                <div class="entry-meta">
                    <span class="last-saved">
                        <?php _e('Last saved:', 'guided-journal'); ?>
                        <span class="save-time"><?php _e('Never', 'guided-journal'); ?></span>
                    </span>
                    <button class="list-toggle">
                        <?php _e('View All Entries', 'guided-journal'); ?>
                    </button>
                </div>
                
                <!-- Entries List -->
                <div id="entriesList" class="entries-list">
                    <div class="entries-header">
                        <h3><?php _e('Your Journal Entries', 'guided-journal'); ?></h3>
                        <div class="entries-filter">
                            <label>
                                <input type="checkbox" id="showCompleted" checked>
                                <?php _e('Show Completed', 'guided-journal'); ?>
                            </label>
                        </div>
                    </div>
                    <div class="entries-content"></div>
                </div>
            </div>
            
            <!-- Progress Modal -->
            <div id="progressModal" class="modal">
                <div class="modal-content">
                    <h3><?php _e('Your Progress', 'guided-journal'); ?></h3>
                    <div class="progress-stats">
                        <div class="stat-item">
                            <span class="stat-label"><?php _e('Completed', 'guided-journal'); ?></span>
                            <span class="stat-value" id="completedEntries">0/30</span>
                        </div>
                        <div class="stat-item">
                            <span class="stat-label"><?php _e('Current Streak', 'guided-journal'); ?></span>
                            <span class="stat-value" id="currentStreak">0</span>
                        </div>
                        <div class="stat-item">
                            <span class="stat-label"><?php _e('Best Streak', 'guided-journal'); ?></span>
                            <span class="stat-value" id="bestStreak">0</span>
                        </div>
                    </div>
                    <div class="progress-calendar"></div>
                    <button class="modal-close"><?php _e('Close', 'guided-journal'); ?></button>
                </div>
            </div>
            
            <!-- Confirmation Modal -->
            <div id="confirmationModal" class="modal">
                <div class="modal-content">
                    <h3><?php _e('Unsaved Changes', 'guided-journal'); ?></h3>
                    <p><?php _e('You have unsaved changes. Would you like to save before leaving?', 'guided-journal'); ?></p>
                    <div class="modal-buttons">
                        <button id="saveAndContinue" class="primary-button">
                            <?php _e('Save & Continue', 'guided-journal'); ?>
                        </button>
                        <button id="discardAndContinue" class="secondary-button">
                            <?php _e('Discard Changes', 'guided-journal'); ?>
                        </button>
                        <button id="cancelNavigation" class="tertiary-button">
                            <?php _e('Cancel', 'guided-journal'); ?>
                        </button>
                    </div>
                </div>
            </div>
            
            <!-- Saving Indicator -->
            <div id="savingIndicator" class="saving-indicator">
                <span class="spinner"></span>
                <span class="saving-text"><?php _e('Saving...', 'guided-journal'); ?></span>
            </div>
        </div>
    </div>
<?php endif; ?>
