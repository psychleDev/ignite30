<?php
/**
 * Circle SSO Handler
 * 
 * Manages Circle Community Single Sign-On integration including
 * authentication, user creation/updates, and session management.
 */

if (!defined('ABSPATH')) {
    die('Direct access is not allowed.');
}

class Circle_SSO {
    /**
     * Circle API endpoints and configuration
     */
    private $client_id;
    private $client_secret;
    private $redirect_uri;
    private $api_base = 'https://app.circle.so/api/v1';
    private $oauth_base = 'https://app.circle.so/oauth';
    private $token_endpoint = '/oauth/token';
    private $user_endpoint = '/me';
    
    /**
     * Initialize Circle SSO
     */
    public function __construct() {
        $this->client_id = get_option('circle_client_id');
        $this->client_secret = get_option('circle_client_secret');
        $this->redirect_uri = home_url('circle-sso-callback');
        
        // Add necessary hooks
        add_action('init', array($this, 'handle_sso_callback'));
        add_action('wp_ajax_verify_circle_session', array($this, 'verify_circle_session'));
        add_action('wp_ajax_nopriv_verify_circle_session', array($this, 'verify_circle_session'));
        add_action('wp_login', array($this, 'sync_circle_data'), 10, 2);
        
        // Add custom rewrite rule for callback
        add_action('init', array($this, 'add_rewrite_rules'));
        
        // Filter authentication
        add_filter('authenticate', array($this, 'authenticate_circle_user'), 10, 3);
    }

    /**
     * Add rewrite rules for SSO callback
     */
    public function add_rewrite_rules() {
        add_rewrite_rule(
            '^circle-sso-callback/?$',
            'index.php?circle_sso=true',
            'top'
        );
        add_rewrite_tag('%circle_sso%', '([0-1]+)');
    }
    
    /**
     * Generate Circle login URL
     */
    public static function get_login_url() {
        $instance = new self();
        return $instance->generate_login_url();
    }
    
    /**
     * Generate the login URL with state parameter
     */
    private function generate_login_url() {
        if (empty($this->client_id)) {
            return false;
        }
        
        $state = wp_generate_password(32, false);
        set_transient('circle_sso_state', $state, HOUR_IN_SECONDS);
        
        $params = array(
            'client_id' => $this->client_id,
            'redirect_uri' => $this->redirect_uri,
            'response_type' => 'code',
            'state' => $state,
            'scope' => 'read'
        );
        
        return $this->oauth_base . '/authorize?' . http_build_query($params);
    }
    
    /**
     * Handle SSO callback from Circle
     */
    public function handle_sso_callback() {
        if (!isset($_GET['circle_sso']) || !isset($_GET['code']) || !isset($_GET['state'])) {
            return;
        }
        
        try {
            $this->verify_state($_GET['state']);
            $token = $this->get_access_token($_GET['code']);
            $user_data = $this->get_user_data($token);
            $user_id = $this->create_or_update_user($user_data);
            
            if (is_wp_error($user_id)) {
                throw new Exception($user_id->get_error_message());
            }
            
            $this->authenticate_user($user_id, $token);
            
            wp_safe_redirect($this->get_redirect_url());
            exit;
            
        } catch (Exception $e) {
            $this->handle_sso_error($e->getMessage());
        }
    }
    
    /**
     * Get access token from Circle
     */
    private function get_access_token($code) {
        $response = wp_remote_post($this->oauth_base . $this->token_endpoint, array(
            'body' => array(
                'client_id' => $this->client_id,
                'client_secret' => $this->client_secret,
                'code' => $code,
                'grant_type' => 'authorization_code',
                'redirect_uri' => $this->redirect_uri
            )
        ));
        
        if (is_wp_error($response)) {
            throw new Exception('Failed to obtain access token: ' . $response->get_error_message());
        }
        
        $body = json_decode(wp_remote_retrieve_body($response), true);
        
        if (empty($body['access_token'])) {
            throw new Exception('Invalid token response from Circle');
        }
        
        return $body['access_token'];
    }
    
    /**
     * Get user data from Circle API
     */
    private function get_user_data($token) {
        $response = wp_remote_get($this->api_base . $this->user_endpoint, array(
            'headers' => array(
                'Authorization' => 'Bearer ' . $token,
                'Accept' => 'application/json'
            )
        ));
        
        if (is_wp_error($response)) {
            throw new Exception('Failed to get user data: ' . $response->get_error_message());
        }
        
        $body = json_decode(wp_remote_retrieve_body($response), true);
        
        if (empty($body['email'])) {
            throw new Exception('Invalid user data from Circle');
        }
        
        return $body;
    }
    
    /**
     * Create or update WordPress user from Circle data
     */
    private function create_or_update_user($circle_data) {
        $user = get_user_by('email', $circle_data['email']);
        
        if (!$user) {
            // Create new user
            $username = $this->generate_username($circle_data);
            $password = wp_generate_password();
            
            $user_id = wp_insert_user(array(
                'user_login' => $username,
                'user_email' => $circle_data['email'],
                'user_pass' => $password,
                'display_name' => $circle_data['name'],
                'role' => 'subscriber'
            ));
            
            if (is_wp_error($user_id)) {
                throw new Exception('Failed to create user: ' . $user_id->get_error_message());
            }
            
            update_user_meta($user_id, 'circle_user_id', $circle_data['id']);
            do_action('circle_user_created', $user_id, $circle_data);
            
            return $user_id;
        }
        
        // Update existing user
        $updated = wp_update_user(array(
            'ID' => $user->ID,
            'display_name' => $circle_data['name']
        ));
        
        if (is_wp_error($updated)) {
            throw new Exception('Failed to update user: ' . $updated->get_error_message());
        }
        
        update_user_meta($user->ID, 'circle_user_id', $circle_data['id']);
        do_action('circle_user_updated', $user->ID, $circle_data);
        
        return $user->ID;
    }
    
    /**
     * Generate unique username from Circle data
     */
    private function generate_username($circle_data) {
        $base_username = sanitize_user(
            strtolower(
                preg_replace('/[^a-zA-Z0-9]/', '', $circle_data['name'])
            ),
            true
        );
        
        // If base username is empty, use part of email
        if (empty($base_username)) {
            $email_parts = explode('@', $circle_data['email']);
            $base_username = sanitize_user($email_parts[0], true);
        }
        
        $username = $base_username;
        $counter = 1;
        
        while (username_exists($username)) {
            $username = $base_username . $counter;
            $counter++;
        }
        
        return $username;
    }
    
    /**
     * Verify state parameter to prevent CSRF
     */
    private function verify_state($state) {
        $saved_state = get_transient('circle_sso_state');
        delete_transient('circle_sso_state');
        
        if (!$saved_state || !hash_equals($saved_state, $state)) {
            throw new Exception('Invalid state parameter');
        }
    }
    
    /**
     * Authenticate user in WordPress
     */
    private function authenticate_user($user_id, $token) {
        wp_set_auth_cookie($user_id, true);
        update_user_meta($user_id, 'circle_access_token', $token);
        wp_set_current_user($user_id);
        do_action('wp_login', wp_get_current_user()->user_login, wp_get_current_user());
    }
    
    /**
     * Verify Circle session status
     */
    public function verify_circle_session() {
        check_ajax_referer('circle_session_nonce', 'nonce');
        
        try {
            $user_id = get_current_user_id();
            if (!$user_id) {
                throw new Exception('User not logged in');
            }
            
            $token = get_user_meta($user_id, 'circle_access_token', true);
            if (!$token) {
                throw new Exception('No Circle token found');
            }
            
            $is_valid = $this->verify_circle_token($token);
            wp_send_json_success(array('valid' => $is_valid));
            
        } catch (Exception $e) {
            wp_send_json_error($e->getMessage());
        }
    }
    
    /**
     * Verify Circle access token
     */
    private function verify_circle_token($token) {
        $response = wp_remote_get($this->api_base . $this->user_endpoint, array(
            'headers' => array(
                'Authorization' => 'Bearer ' . $token
            )
        ));
        
        return !is_wp_error($response) && wp_remote_retrieve_response_code($response) === 200;
    }
    
    /**
     * Get redirect URL after successful login
     */
    private function get_redirect_url() {
        $default_url = home_url();
        $redirect_to = isset($_GET['redirect_to']) ? $_GET['redirect_to'] : '';
        
        if (empty($redirect_to)) {
            return $default_url;
        }
        
        $redirect_to = wp_sanitize_redirect($redirect_to);
        return wp_validate_redirect($redirect_to, $default_url);
    }
    
    /**
     * Handle SSO errors
     */
    private function handle_sso_error($message) {
        error_log('Circle SSO Error: ' . $message);
        wp_redirect(add_query_arg(
            'circle_sso_error',
            urlencode($message),
            wp_login_url()
        ));
        exit;
    }
}
