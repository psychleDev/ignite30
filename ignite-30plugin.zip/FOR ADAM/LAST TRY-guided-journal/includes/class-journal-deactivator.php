<?php
/**
 * Journal Plugin Deactivator
 * 
 * Handles all deactivation procedures for the journal plugin.
 * Cleans up temporary data while preserving user entries.
 */

class Journal_Deactivator {
    /**
     * Deactivate the plugin
     * 
     * Performs cleanup operations while maintaining user data integrity
     */
    public static function deactivate() {
        self::cleanup_temporary_data();
        self::clear_scheduled_events();
        self::backup_settings();
        self::log_deactivation();
    }
    
    /**
     * Clean up temporary data and transients
     */
    private static function cleanup_temporary_data() {
        // Clear plugin-specific transients
        delete_transient('journal_activation_notice');
        delete_transient('circle_sso_state');
        delete_transient('journal_daily_backup_lock');
        delete_transient('journal_maintenance_lock');
        
        // Clear cached data
        wp_cache_delete('journal_global_stats', 'journal');
        wp_cache_delete('journal_active_users', 'journal');
        
        // Clean up any temporary files
        $upload_dir = wp_upload_dir();
        $temp_dir = $upload_dir['basedir'] . '/journal-entries/temp';
        if (file_exists($temp_dir)) {
            self::remove_directory($temp_dir);
        }
    }
    
    /**
     * Clear all scheduled events
     */
    private static function clear_scheduled_events() {
        // Remove all scheduled cron events
        wp_clear_scheduled_hook('journal_daily_backup');
        wp_clear_scheduled_hook('journal_cleanup_old_backups');
        wp_clear_scheduled_hook('journal_maintenance_routine');
        wp_clear_scheduled_hook('journal_check_user_streaks');
        
        // Log any pending tasks that weren't completed
        self::log_pending_tasks();
    }
    
    /**
     * Backup plugin settings
     */
    private static function backup_settings() {
        $settings = array(
            'circle_client_id' => get_option('circle_client_id'),
            'circle_client_secret' => get_option('circle_client_secret'),
            'circle_community_url' => get_option('circle_community_url'),
            'journal_settings' => get_option('journal_settings'),
            'journal_prompts' => get_option('journal_prompts'),
            'journal_db_version' => get_option('journal_db_version')
        );
        
        update_option('journal_backup_settings', $settings);
    }
    
    /**
     * Log deactivation details for troubleshooting
     */
    private static function log_deactivation() {
        $log = array(
            'timestamp' => current_time('mysql'),
            'wp_version' => get_bloginfo('version'),
            'plugin_version' => JOURNAL_PLUGIN_VERSION,
            'deactivated_by' => get_current_user_id(),
            'active_users' => self::get_active_users_count(),
            'total_entries' => self::get_total_entries_count(),
            'php_version' => PHP_VERSION,
            'mysql_version' => self::get_mysql_version()
        );
        
        update_option('journal_last_deactivation', $log);
    }
    
    /**
     * Get count of active users
     */
    private static function get_active_users_count() {
        global $wpdb;
        $table_name = $wpdb->prefix . 'journal_user_progress';
        return $wpdb->get_var("SELECT COUNT(DISTINCT user_id) FROM $table_name WHERE last_entry_date >= DATE_SUB(NOW(), INTERVAL 30 DAY)");
    }
    
    /**
     * Get total number of journal entries
     */
    private static function get_total_entries_count() {
        global $wpdb;
        $table_name = $wpdb->prefix . 'journal_entries';
        return $wpdb->get_var("SELECT COUNT(*) FROM $table_name");
    }
    
    /**
     * Get MySQL version
     */
    private static function get_mysql_version() {
        global $wpdb;
        return $wpdb->get_var("SELECT VERSION()");
    }
    
    /**
     * Log any pending tasks that weren't completed
     */
    private static function log_pending_tasks() {
        global $wpdb;
        
        $pending_tasks = array();
        
        // Check for pending backups
        $backup_table = $wpdb->prefix . 'journal_entry_backups';
        $pending_backups = $wpdb->get_var("SELECT COUNT(*) FROM $backup_table WHERE created_at >= DATE_SUB(NOW(), INTERVAL 24 HOUR)");
        if ($pending_backups > 0) {
            $pending_tasks['backups'] = $pending_backups;
        }
        
        // Check for entries being processed
        $entries_table = $wpdb->prefix . 'journal_entries';
        $processing_entries = $wpdb->get_var("SELECT COUNT(*) FROM $entries_table WHERE updated_at > created_at AND updated_at >= DATE_SUB(NOW(), INTERVAL 1 HOUR)");
        if ($processing_entries > 0) {
            $pending_tasks['processing_entries'] = $processing_entries;
        }
        
        if (!empty($pending_tasks)) {
            update_option('journal_pending_tasks', $pending_tasks);
        }
    }
    
    /**
     * Recursively remove a directory and its contents
     */
    private static function remove_directory($dir) {
        if (!file_exists($dir)) {
            return true;
        }
        
        if (!is_dir($dir)) {
            return unlink($dir);
        }
        
        foreach (scandir($dir) as $item) {
            if ($item == '.' || $item == '..') {
                continue;
            }
            
            if (!self::remove_directory($dir . DIRECTORY_SEPARATOR . $item)) {
                return false;
            }
        }
        
        return rmdir($dir);
    }
    
    /**
     * Handle complete uninstall if requested
     */
    public static function uninstall() {
        // Check if we should remove all data
        $settings = get_option('journal_settings');
        if (!empty($settings['delete_data_on_uninstall'])) {
            self::remove_all_data();
        }
    }
    
    /**
     * Remove all plugin data
     */
    private static function remove_all_data() {
        global $wpdb;
        
        // Remove database tables
        $tables = array(
            $wpdb->prefix . 'journal_entries',
            $wpdb->prefix . 'journal_user_progress',
            $wpdb->prefix . 'journal_entry_backups'
        );
        
        foreach ($tables as $table) {
            $wpdb->query("DROP TABLE IF EXISTS $table");
        }
        
        // Remove options
        $options = array(
            'circle_client_id',
            'circle_client_secret',
            'circle_community_url',
            'journal_settings',
            'journal_prompts',
            'journal_db_version',
            'journal_backup_settings',
            'journal_last_deactivation',
            'journal_pending_tasks'
        );
        
        foreach ($options as $option) {
            delete_option($option);
        }
        
        // Remove upload directory
        $upload_dir = wp_upload_dir();
        $journal_dir = $upload_dir['basedir'] . '/journal-entries';
        self::remove_directory($journal_dir);
        
        // Remove user meta
        $wpdb->query("DELETE FROM $wpdb->usermeta WHERE meta_key LIKE 'journal_%'");
    }
}
