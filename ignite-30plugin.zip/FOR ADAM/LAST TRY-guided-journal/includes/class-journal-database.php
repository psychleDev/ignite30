<?php
/**
 * Journal Database Handler
 * 
 * Manages all database operations for the journal plugin.
 */

if (!defined('ABSPATH')) {
    die('Direct access is not allowed.');
}

class Journal_Database {
    /**
     * @var wpdb WordPress database object
     */
    private $wpdb;

    /**
     * @var string Table names
     */
    private $entries_table;
    private $progress_table;
    private $backup_table;

    /**
     * @var Journal_Encryption Encryption handler
     */
    private $encryption;

    /**
     * Initialize database handler
     */
    public function __construct() {
        global $wpdb;
        $this->wpdb = $wpdb;
        $this->entries_table = $wpdb->prefix . 'journal_entries';
        $this->progress_table = $wpdb->prefix . 'journal_user_progress';
        $this->backup_table = $wpdb->prefix . 'journal_entry_backups';
        
        // Initialize encryption
        require_once JOURNAL_PLUGIN_DIR . 'includes/class-journal-encryption.php';
        $this->encryption = new Journal_Encryption();

        // Register AJAX handlers
        add_action('wp_ajax_save_journal_entry', array($this, 'handle_save_entry'));
        add_action('wp_ajax_get_journal_entry', array($this, 'handle_get_entry'));
        add_action('wp_ajax_get_journal_entries', array($this, 'handle_get_entries'));
        add_action('wp_ajax_delete_journal_entry', array($this, 'handle_delete_entry'));

        // Register cleanup hooks
        add_action('journal_daily_backup', array($this, 'perform_daily_backup'));
        add_action('journal_cleanup_old_backups', array($this, 'cleanup_old_backups'));
    }

    /**
     * Verify tables exist
     * @return bool
     */
    public function verify_tables() {
        $tables = array(
            $this->entries_table,
            $this->progress_table,
            $this->backup_table
        );

        foreach ($tables as $table) {
            if (!$this->table_exists($table)) {
                return false;
            }
        }
        return true;
    }

    /**
     * Handle save entry AJAX request
     */
    public function handle_save_entry() {
        try {
            // Verify nonce and user
            check_ajax_referer('journal_nonce', 'nonce');
            if (!is_user_logged_in()) {
                throw new Exception(__('User not logged in', 'guided-journal'));
            }

            // Validate input
            $data = $this->validate_entry_data($_POST);
            if (is_wp_error($data)) {
                throw new Exception($data->get_error_message());
            }

            // Save entry
            $result = $this->save_entry(get_current_user_id(), $data);
            if (is_wp_error($result)) {
                throw new Exception($result->get_error_message());
            }

            wp_send_json_success(array(
                'entry_id' => $result,
                'message' => __('Entry saved successfully', 'guided-journal')
            ));

        } catch (Exception $e) {
            wp_send_json_error($e->getMessage());
        }
    }

    /**
     * Save journal entry
     * 
     * @param int $user_id
     * @param array $data
     * @return int|WP_Error Entry ID or error
     */
    public function save_entry($user_id, $data) {
        try {
            $this->wpdb->query('START TRANSACTION');

            // Prepare entry data
            $entry_data = array(
                'user_id' => $user_id,
                'circle_user_id' => get_user_meta($user_id, 'circle_user_id', true),
                'day_number' => $data['day_number'],
                'entry_content' => $data['entry_content'],
                'visibility' => $data['visibility'],
                'word_count' => str_word_count(wp_strip_all_tags($data['entry_content'])),
                'is_completed' => 1,
                'meta_data' => isset($data['meta_data']) ? json_encode($data['meta_data']) : null
            );

            // Encrypt if private
            if ($data['visibility'] === 'private') {
                $encryption_result = $this->encrypt_entry_content($data['entry_content']);
                if (is_wp_error($encryption_result)) {
                    throw new Exception($encryption_result->get_error_message());
                }
                $entry_data = array_merge($entry_data, $encryption_result);
            }

            // Insert or update entry
            $existing_id = $this->get_existing_entry_id($user_id, $data['day_number']);
            
            if ($existing_id) {
                // Backup existing entry
                $this->backup_entry($existing_id);
                
                // Update
                $result = $this->wpdb->update(
                    $this->entries_table,
                    $entry_data,
                    array('id' => $existing_id),
                    array('%d', '%s', '%d', '%s', '%s', '%d', '%d', '%s'),
                    array('%d')
                );
                
                $entry_id = $existing_id;
            } else {
                // Insert
                $result = $this->wpdb->insert(
                    $this->entries_table,
                    $entry_data,
                    array('%d', '%s', '%d', '%s', '%s', '%d', '%d', '%s')
                );
                
                $entry_id = $this->wpdb->insert_id;
            }

            if ($result === false) {
                throw new Exception($this->wpdb->last_error);
            }

            // Update user progress
            $this->update_user_progress($user_id);

            $this->wpdb->query('COMMIT');
            return $entry_id;

        } catch (Exception $e) {
            $this->wpdb->query('ROLLBACK');
            return new WP_Error('db_error', $e->getMessage());
        }
    }

    /**
     * Handle get entry AJAX request
     */
    public function handle_get_entry() {
        try {
            check_ajax_referer('journal_nonce', 'nonce');
            if (!is_user_logged_in()) {
                throw new Exception(__('User not logged in', 'guided-journal'));
            }

            $day_number = isset($_POST['day_number']) ? intval($_POST['day_number']) : 0;
            if ($day_number < 1 || $day_number > 30) {
                throw new Exception(__('Invalid day number', 'guided-journal'));
            }

            $entry = $this->get_entry(get_current_user_id(), $day_number);
            if (is_wp_error($entry)) {
                throw new Exception($entry->get_error_message());
            }

            wp_send_json_success($entry);

        } catch (Exception $e) {
            wp_send_json_error($e->getMessage());
        }
    }

    /**
     * Get journal entry
     * 
     * @param int $user_id
     * @param int $day_number
     * @return object|WP_Error Entry data or error
     */
    public function get_entry($user_id, $day_number) {
        $entry = $this->wpdb->get_row($this->wpdb->prepare(
            "SELECT * FROM {$this->entries_table} 
            WHERE user_id = %d AND day_number = %d",
            $user_id,
            $day_number
        ));

        if (!$entry) {
            return null;
        }

        // Decrypt if private
        if ($entry->visibility === 'private') {
            $decrypted = $this->decrypt_entry_content($entry);
            if (is_wp_error($decrypted)) {
                return $decrypted;
            }
            $entry->entry_content = $decrypted;
        }

        $entry->meta_data = $entry->meta_data ? json_decode($entry->meta_data, true) : array();
        return $entry;
    }

    /**
     * Encrypt entry content
     * 
     * @param string $content
     * @return array|WP_Error
     */
    private function encrypt_entry_content($content) {
        try {
            $key = $this->encryption->generate_key();
            $encrypted = $this->encryption->encrypt($content, $key);
            
            if ($encrypted === false) {
                throw new Exception(__('Encryption failed', 'guided-journal'));
            }

            return array(
                'entry_content' => json_encode($encrypted),
                'encryption_key' => $key
            );

        } catch (Exception $e) {
            return new WP_Error('encryption_failed', $e->getMessage());
        }
    }

    /**
     * Decrypt entry content
     * 
     * @param object $entry
     * @return string|WP_Error
     */
    private function decrypt_entry_content($entry) {
        try {
            $encrypted_data = json_decode($entry->entry_content, true);
            if (!$encrypted_data || !$entry->encryption_key) {
                throw new Exception(__('Invalid encrypted data', 'guided-journal'));
            }

            $decrypted = $this->encryption->decrypt($encrypted_data, $entry->encryption_key);
            if ($decrypted === false) {
                throw new Exception(__('Decryption failed', 'guided-journal'));
            }

            return $decrypted;

        } catch (Exception $e) {
            return new WP_Error('decryption_failed', $e->getMessage());
        }
    }

    /**
     * Update user progress
     * 
     * @param int $user_id
     */
    private function update_user_progress($user_id) {
        $stats = $this->wpdb->get_row($this->wpdb->prepare(
            "SELECT 
                COUNT(*) as total_entries,
                COUNT(DISTINCT day_number) as completed_days,
                MAX(created_at) as last_entry_date
            FROM {$this->entries_table}
            WHERE user_id = %d",
            $user_id
        ));

        $streak = $this->calculate_streak($user_id);

        $this->wpdb->replace(
            $this->progress_table,
            array(
                'user_id' => $user_id,
                'total_entries' => $stats->total_entries,
                'completed_days' => $stats->completed_days,
                'streak_count' => $streak,
                'last_entry_date' => $stats->last_entry_date
            ),
            array('%d', '%d', '%d', '%d', '%s')
        );
    }

    /**
     * Calculate user's current streak
     * 
     * @param int $user_id
     * @return int
     */
    private function calculate_streak($user_id) {
        $entries = $this->wpdb->get_results($this->wpdb->prepare(
            "SELECT DATE(created_at) as entry_date
            FROM {$this->entries_table}
            WHERE user_id = %d
            ORDER BY created_at DESC",
            $user_id
        ));

        if (empty($entries)) {
            return 0;
        }

        $streak = 1;
        $current_date = strtotime($entries[0]->entry_date);

        // Check if streak is still alive (within 24 hours)
        if (date('Y-m-d', $current_date) !== date('Y-m-d')) {
            if (time() - $current_date > 86400) {
                return 0;
            }
        }

        for ($i = 1; $i < count($entries); $i++) {
            $prev_date = strtotime($entries[$i]->entry_date);
            $diff = round(($current_date - $prev_date) / 86400);

            if ($diff !== 1) {
                break;
            }

            $streak++;
            $current_date = $prev_date;
        }

        return $streak;
    }

    /**
     * Check if table exists
     * 
     * @param string $table_name
     * @return bool
     */
    private function table_exists($table_name) {
        return $this->wpdb->get_var(
            $this->wpdb->prepare(
                "SHOW TABLES LIKE %s",
                $table_name
            )
        ) === $table_name;
    }

    /**
     * Validate entry data
     * 
     * @param array $data
     * @return array|WP_Error
     */
    private function validate_entry_data($data) {
        $validated = array();

        // Validate day number
        $day_number = isset($data['day_number']) ? intval($data['day_number']) : 0;
        if ($day_number < 1 || $day_number > 30) {
            return new WP_Error('invalid_day', __('Invalid day number', 'guided-journal'));
        }
        $validated['day_number'] = $day_number;

        // Validate content
        if (empty($data['entry_content'])) {
            return new WP_Error('empty_content', __('Entry content cannot be empty', 'guided-journal'));
        }
        $validated['entry_content'] = wp_kses_post($data['entry_content']);

        // Validate visibility
        $visibility = isset($data['visibility']) ? sanitize_text_field($data['visibility']) : '';
        if (!in_array($visibility, array('private', 'community', 'public'))) {
            return new WP_Error('invalid_visibility', __('Invalid visibility setting', 'guided-journal'));
        }
        $validated['visibility'] = $visibility;

        return $validated;
    }

    /**
     * Get existing entry ID
     * 
     * @param int $user_id
     * @param int $day_number
     * @return int|null
     */
    private function get_existing_entry_id($user_id, $day_number) {
        return $this->wpdb->get_var($this->wpdb->prepare(
            "SELECT id FROM {$this->entries_table} 
            WHERE user_id = %d AND day_number = %d",
            $user_id,
            $day_number
        ));
    }

    /**
     * Backup entry
     * 
     * @param int $entry_id
     * @return bool
     */
    private function backup_entry($entry_id) {
        $entry = $this->wpdb->get_row($this->wpdb->prepare(
            "SELECT * FROM {$this->entries_table} WHERE id = %d",
            $entry_id
        ));

        if ($entry) {
            return $this->wpdb->insert(
                $this->backup_table,
                array(
                    'entry_id' => $entry_id,
                    'user_id' => $entry->user_id,
                    'entry_content' => $entry->entry_content,
                    'created_at' => current_time('mysql')
                ),
                array('%d', '%d', '%s', '%s')
            );
        }

        return false;
    }
}
