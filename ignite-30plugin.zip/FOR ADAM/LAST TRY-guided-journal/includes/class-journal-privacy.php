<?php
/**
 * Journal Privacy Handler
 * 
 * Manages privacy-related functionality including GDPR compliance,
 * data export, and data erasure requests.
 */

class Journal_Privacy {
    private $encryption;
    
    /**
     * Initialize privacy handler
     */
    public function __construct() {
        $this->encryption = new Journal_Encryption();
        
        // Register privacy hooks
        add_action('admin_init', array($this, 'register_privacy_policy'));
        add_filter('wp_privacy_personal_data_exporters', array($this, 'register_exporter'));
        add_filter('wp_privacy_personal_data_erasers', array($this, 'register_eraser'));
        
        // Add privacy-related hooks
        add_action('init', array($this, 'register_privacy_controls'));
        add_action('template_redirect', array($this, 'enforce_privacy_settings'));
    }
    
    /**
     * Register privacy policy content
     */
    public function register_privacy_policy() {
        if (!function_exists('wp_add_privacy_policy_content')) {
            return;
        }
        
        $content = sprintf(
            '<h3>%s</h3>' .
            '<p>%s</p>' .
            '<h4>%s</h4>' .
            '<p>%s</p>' .
            '<h4>%s</h4>' .
            '<p>%s</p>' .
            '<h4>%s</h4>' .
            '<p>%s</p>',
            __('Journal Entries', 'guided-journal'),
            __('When you use our journaling feature, we store your entries in our database. The information you provide is handled with utmost care and according to your privacy preferences.', 'guided-journal'),
            __('What we collect', 'guided-journal'),
            __('We collect and store the journal entries you create, including the content, date, and privacy settings. For Circle community members, we also store your Circle user ID to enable single sign-on functionality.', 'guided-journal'),
            __('How we protect your data', 'guided-journal'),
            __('Private entries are encrypted using industry-standard encryption before being stored in our database. Only you can access these entries. Entries marked as "community" are visible only to Circle community members, while "public" entries may be visible to anyone.', 'guided-journal'),
            __('Your privacy rights', 'guided-journal'),
            __('You can export or delete your journal data at any time through the WordPress privacy tools. You maintain full control over your entries and can modify their privacy settings at any time.', 'guided-journal')
        );
        
        wp_add_privacy_policy_content('Guided Journal', wp_kses_post($content));
    }
    
    /**
     * Register data exporter
     */
    public function register_exporter($exporters) {
        $exporters['guided-journal'] = array(
            'exporter_friendly_name' => __('Journal Entries', 'guided-journal'),
            'callback' => array($this, 'export_user_data'),
        );
        return $exporters;
    }
    
    /**
     * Register data eraser
     */
    public function register_eraser($erasers) {
        $erasers['guided-journal'] = array(
            'eraser_friendly_name' => __('Journal Entries', 'guided-journal'),
            'callback' => array($this, 'erase_user_data'),
        );
        return $erasers;
    }
    
    /**
     * Export user data
     * 
     * @param string $email_address User email address
     * @return array Export data and status
     */
    public function export_user_data($email_address) {
        $user = get_user_by('email', $email_address);
        if (!$user) {
            return array(
                'data' => array(),
                'done' => true,
            );
        }
        
        global $wpdb;
        $table_name = $wpdb->prefix . 'journal_entries';
        
        $entries = $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM $table_name WHERE user_id = %d ORDER BY day_number ASC",
            $user->ID
        ));
        
        $export_items = array();
        
        foreach ($entries as $entry) {
            $data = array();
            $content = $entry->entry_content;
            
            // Decrypt private entries
            if ($entry->visibility === 'private' && !empty($entry->encryption_key)) {
                $encrypted_data = json_decode($content, true);
                if ($encrypted_data && $this->encryption->is_encrypted($encrypted_data)) {
                    $content = $this->encryption->decrypt($encrypted_data, $entry->encryption_key);
                }
            }
            
            $data[] = array(
                'name' => __('Day', 'guided-journal') . ' ' . $entry->day_number,
                'value' => $content
            );
            
            $data[] = array(
                'name' => __('Created', 'guided-journal'),
                'value' => $entry->created_at
            );
            
            $data[] = array(
                'name' => __('Privacy Level', 'guided-journal'),
                'value' => ucfirst($entry->visibility)
            );
            
            $export_items[] = array(
                'group_id' => 'journal-entries',
                'group_label' => __('Journal Entries', 'guided-journal'),
                'item_id' => 'entry-' . $entry->id,
                'data' => $data,
            );
        }
        
        return array(
            'data' => $export_items,
            'done' => true,
        );
    }
    
    /**
     * Erase user data
     * 
     * @param string $email_address User email address
     * @return array Erasure status
     */
    public function erase_user_data($email_address) {
        $user = get_user_by('email', $email_address);
        if (!$user) {
            return array(
                'items_removed' => false,
                'items_retained' => false,
                'messages' => array(),
                'done' => true,
            );
        }
        
        global $wpdb;
        $table_name = $wpdb->prefix . 'journal_entries';
        
        // Create backup before deletion if enabled
        if (get_option('journal_backup_before_erasure', true)) {
            $this->backup_user_data($user->ID);
        }
        
        // Delete entries
        $deleted = $wpdb->delete(
            $table_name,
            array('user_id' => $user->ID),
            array('%d')
        );
        
        // Delete user meta
        delete_user_meta($user->ID, 'journal_settings');
        delete_user_meta($user->ID, 'journal_progress');
        
        return array(
            'items_removed' => $deleted !== false,
            'items_retained' => false,
            'messages' => array(
                __('All journal entries have been deleted.', 'guided-journal')
            ),
            'done' => true,
        );
    }
    
    /**
     * Register privacy control options
     */
    private function register_privacy_controls() {
        add_option('journal_privacy_settings', array(
            'allow_public_entries' => true,
            'allow_community_entries' => true,
            'default_visibility' => 'private',
            'backup_before_erasure' => true,
            'auto_anonymize_after' => 0, // days, 0 = never
            'retention_period' => 0 // days, 0 = indefinite
        ));
    }
    
    /**
     * Enforce privacy settings
     */
    public function enforce_privacy_settings() {
        if (!is_user_logged_in()) {
            return;
        }
        
        $settings = get_option('journal_privacy_settings');
        
        // Check retention period
        if ($settings['retention_period'] > 0) {
            $this->handle_retention_period($settings['retention_period']);
        }
        
        // Check auto-anonymization
        if ($settings['auto_anonymize_after'] > 0) {
            $this->handle_auto_anonymization($settings['auto_anonymize_after']);
        }
    }
    
    /**
     * Handle data retention period
     * 
     * @param int $days Number of days to retain data
     */
    private function handle_retention_period($days) {
        global $wpdb;
        $table_name = $wpdb->prefix . 'journal_entries';
        
        $cutoff_date = date('Y-m-d H:i:s', strtotime("-{$days} days"));
        
        $wpdb->query($wpdb->prepare(
            "DELETE FROM $table_name WHERE created_at < %s",
            $cutoff_date
        ));
    }
    
    /**
     * Handle auto-anonymization of old entries
     * 
     * @param int $days Number of days before anonymization
     */
    private function handle_auto_anonymization($days) {
        global $wpdb;
        $table_name = $wpdb->prefix . 'journal_entries';
        
        $cutoff_date = date('Y-m-d H:i:s', strtotime("-{$days} days"));
        
        $entries = $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM $table_name WHERE created_at < %s AND user_id != 0",
            $cutoff_date
        ));
        
        foreach ($entries as $entry) {
            $this->anonymize_entry($entry);
        }
    }
    
    /**
     * Anonymize a single entry
     * 
     * @param object $entry Entry to anonymize
     */
    private function anonymize_entry($entry) {
        global $wpdb;
        $table_name = $wpdb->prefix . 'journal_entries';
        
        $wpdb->update(
            $table_name,
            array(
                'user_id' => 0,
                'circle_user_id' => '',
                'meta_data' => null
            ),
            array('id' => $entry->id),
            array('%d', '%s', null),
            array('%d')
        );
    }
    
    /**
     * Backup user data before erasure
     * 
     * @param int $user_id User ID
     */
    private function backup_user_data($user_id) {
        global $wpdb;
        $table_name = $wpdb->prefix . 'journal_entries';
        $backup_table = $wpdb->prefix . 'journal_entry_backups';
        
        $entries = $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM $table_name WHERE user_id = %d",
            $user_id
        ));
        
        foreach ($entries as $entry) {
            $wpdb->insert(
                $backup_table,
                array(
                    'entry_id' => $entry->id,
                    'user_id' => $user_id,
                    'entry_content' => $entry->entry_content,
                    'created_at' => current_time('mysql')
                ),
                array('%d', '%d', '%s', '%s')
            );
        }
    }
}
