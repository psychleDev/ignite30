<?php
/**
 * Create necessary database tables
 * 
 * @return void
 * @throws Exception
 */
private static function create_database_tables() {
    global $wpdb;
    $charset_collate = $wpdb->get_charset_collate();

    // Required for dbDelta
    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');

    // Each table creation in separate try/catch
    try {
        // Entries table
        $entries_table = $wpdb->prefix . 'journal_entries';
        $sql_entries = "CREATE TABLE IF NOT EXISTS {$entries_table} (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            user_id bigint(20) unsigned NOT NULL,
            circle_user_id varchar(255) DEFAULT NULL,
            day_number int(11) NOT NULL,
            entry_content longtext NOT NULL,
            visibility enum('private','community','public') DEFAULT 'private',
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            updated_at datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            encryption_key varchar(255) DEFAULT NULL,
            encryption_iv varchar(255) DEFAULT NULL,
            word_count int(11) DEFAULT 0,
            is_completed tinyint(1) DEFAULT 0,
            meta_data longtext DEFAULT NULL,
            PRIMARY KEY  (id),
            KEY user_id (user_id),
            KEY day_number (day_number),
            KEY visibility (visibility)
        ) $charset_collate;";

        dbDelta($sql_entries);
        if (!self::table_exists($entries_table)) {
            throw new Exception("Failed to create entries table");
        }

        // Progress table
        $progress_table = $wpdb->prefix . 'journal_user_progress';
        $sql_progress = "CREATE TABLE IF NOT EXISTS {$progress_table} (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            user_id bigint(20) unsigned NOT NULL,
            total_entries int(11) NOT NULL DEFAULT 0,
            completed_days int(11) NOT NULL DEFAULT 0,
            streak_count int(11) NOT NULL DEFAULT 0,
            last_entry_date datetime DEFAULT NULL,
            settings longtext DEFAULT NULL,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            updated_at datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY  (id),
            UNIQUE KEY user_id (user_id)
        ) $charset_collate;";

        dbDelta($sql_progress);
        if (!self::table_exists($progress_table)) {
            throw new Exception("Failed to create progress table");
        }

        // Backup table
        $backup_table = $wpdb->prefix . 'journal_entry_backups';
        $sql_backup = "CREATE TABLE IF NOT EXISTS {$backup_table} (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            entry_id bigint(20) unsigned NOT NULL,
            user_id bigint(20) unsigned NOT NULL,
            entry_content longtext NOT NULL,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY  (id),
            KEY entry_id (entry_id),
            KEY user_id (user_id)
        ) $charset_collate;";

        dbDelta($sql_backup);
        if (!self::table_exists($backup_table)) {
            throw new Exception("Failed to create backup table");
        }

        return true;

    } catch (Exception $e) {
        // Log the error and throw it up
        error_log('Journal Plugin Table Creation Error: ' . $e->getMessage());
        throw new Exception('Database creation failed: ' . $e->getMessage());
    }
}

/**
 * Check if a table exists
 * 
 * @param string $table_name
 * @return bool
 */
private static function table_exists($table_name) {
    global $wpdb;
    $table = $wpdb->get_var($wpdb->prepare(
        "SHOW TABLES LIKE %s",
        $wpdb->esc_like($table_name)
    ));
    return ($table === $table_name);
}

/**
 * Set up default options
 * 
 * @return void
 */
private static function setup_default_options() {
    // Default journal settings
    $default_settings = array(
        'auto_save_interval' => 60,
        'min_word_count' => 0,
        'max_word_count' => 0,
        'allow_public_entries' => true,
        'allow_community_entries' => true,
        'backup_entries' => true,
        'delete_data_on_uninstall' => false,
        'encryption_enabled' => true
    );
    
    update_option('journal_settings', $default_settings);
    update_option('journal_version', JOURNAL_PLUGIN_VERSION);
}
