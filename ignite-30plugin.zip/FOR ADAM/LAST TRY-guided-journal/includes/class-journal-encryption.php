<?php
/**
 * Journal Encryption Handler
 * 
 * Handles encryption and decryption of journal entries using OpenSSL
 * with AES-256-CBC encryption and proper key derivation.
 */

class Journal_Encryption {
    /**
     * Encryption configuration
     */
    private $cipher = 'aes-256-cbc';
    private $hash_algo = 'sha256';
    private $pbkdf2_iterations = 10000;
    private $pbkdf2_key_length = 32; // 256 bits
    private $auth_key_salt;
    private $encryption_key_salt;
    
    /**
     * Initialize encryption system
     */
    public function __construct() {
        // Initialize salts if they don't exist
        $this->initialize_salts();
        
        // Verify encryption system requirements
        $this->verify_requirements();
    }
    
    /**
     * Initialize encryption/authentication salts
     */
    private function initialize_salts() {
        $this->auth_key_salt = defined('AUTH_SALT') ? AUTH_SALT : wp_generate_password(64, true, true);
        $this->encryption_key_salt = defined('SECURE_AUTH_SALT') ? SECURE_AUTH_SALT : wp_generate_password(64, true, true);
    }
    
    /**
     * Verify encryption system requirements
     */
    private function verify_requirements() {
        if (!extension_loaded('openssl')) {
            throw new Exception('OpenSSL extension is required for encryption.');
        }
        
        if (!in_array($this->cipher, openssl_get_cipher_methods())) {
            throw new Exception('Required cipher method is not available.');
        }
        
        if (!function_exists('openssl_random_pseudo_bytes')) {
            throw new Exception('Cryptographically secure random bytes generator is not available.');
        }
    }
    
    /**
     * Encrypt data
     * 
     * @param string $data Data to encrypt
     * @param string $key_seed Seed for key derivation
     * @return array|false Encrypted data array or false on failure
     */
    public function encrypt($data, $key_seed) {
        try {
            // Generate encryption key and IV
            $encryption_key = $this->derive_key($key_seed, $this->encryption_key_salt);
            $iv = openssl_random_pseudo_bytes(openssl_cipher_iv_length($this->cipher));
            
            // Encrypt the data
            $encrypted = openssl_encrypt(
                $data,
                $this->cipher,
                $encryption_key,
                OPENSSL_RAW_DATA,
                $iv
            );
            
            if ($encrypted === false) {
                throw new Exception('Encryption failed: ' . openssl_error_string());
            }
            
            // Generate authentication key and HMAC
            $auth_key = $this->derive_key($key_seed, $this->auth_key_salt);
            $hmac = hash_hmac($this->hash_algo, $encrypted . $iv, $auth_key, true);
            
            // Combine elements and encode
            return array(
                'data' => base64_encode($encrypted),
                'iv' => base64_encode($iv),
                'hmac' => base64_encode($hmac),
                'version' => 1 // For future compatibility
            );
        } catch (Exception $e) {
            $this->log_error('Encryption failed: ' . $e->getMessage());
            return false;
        }
    }
    
    /**
     * Decrypt data
     * 
     * @param array $encrypted_data Encrypted data array
     * @param string $key_seed Seed for key derivation
     * @return string|false Decrypted data or false on failure
     */
    public function decrypt($encrypted_data, $key_seed) {
        try {
            // Validate input format
            $this->validate_encrypted_data($encrypted_data);
            
            // Decode components
            $encrypted = base64_decode($encrypted_data['data']);
            $iv = base64_decode($encrypted_data['iv']);
            $hmac = base64_decode($encrypted_data['hmac']);
            
            // Generate authentication key and verify HMAC
            $auth_key = $this->derive_key($key_seed, $this->auth_key_salt);
            $calculated_hmac = hash_hmac($this->hash_algo, $encrypted . $iv, $auth_key, true);
            
            if (!hash_equals($hmac, $calculated_hmac)) {
                throw new Exception('HMAC verification failed');
            }
            
            // Generate encryption key and decrypt
            $encryption_key = $this->derive_key($key_seed, $this->encryption_key_salt);
            $decrypted = openssl_decrypt(
                $encrypted,
                $this->cipher,
                $encryption_key,
                OPENSSL_RAW_DATA,
                $iv
            );
            
            if ($decrypted === false) {
                throw new Exception('Decryption failed: ' . openssl_error_string());
            }
            
            return $decrypted;
        } catch (Exception $e) {
            $this->log_error('Decryption failed: ' . $e->getMessage());
            return false;
        }
    }
    
    /**
     * Derive encryption/authentication keys using PBKDF2
     * 
     * @param string $key_seed Base key for derivation
     * @param string $salt Salt for key derivation
     * @return string Derived key
     */
    private function derive_key($key_seed, $salt) {
        if (function_exists('hash_pbkdf2')) {
            return hash_pbkdf2(
                $this->hash_algo,
                $key_seed,
                $salt,
                $this->pbkdf2_iterations,
                $this->pbkdf2_key_length,
                true
            );
        }
        
        // Fallback to manual PBKDF2 implementation
        return $this->pbkdf2(
            $this->hash_algo,
            $key_seed,
            $salt,
            $this->pbkdf2_iterations,
            $this->pbkdf2_key_length
        );
    }
    
    /**
     * Manual PBKDF2 implementation for systems without hash_pbkdf2
     */
    private function pbkdf2($algorithm, $password, $salt, $iterations, $length) {
        $hash_length = strlen(hash($algorithm, '', true));
        $block_count = ceil($length / $hash_length);
        $output = '';
        
        for ($i = 1; $i <= $block_count; $i++) {
            $last = $salt . pack('N', $i);
            $last = $xorsum = hash_hmac($algorithm, $last, $password, true);
            
            for ($j = 1; $j < $iterations; $j++) {
                $xorsum ^= ($last = hash_hmac($algorithm, $last, $password, true));
            }
            
            $output .= $xorsum;
        }
        
        return substr($output, 0, $length);
    }
    
    /**
     * Generate a new encryption key
     * 
     * @return string New encryption key
     */
    public function generate_key() {
        return base64_encode(openssl_random_pseudo_bytes(32));
    }
    
    /**
     * Validate encrypted data array structure
     * 
     * @param array $data Encrypted data array to validate
     * @throws Exception If data is invalid
     */
    private function validate_encrypted_data($data) {
        $required_keys = array('data', 'iv', 'hmac', 'version');
        
        foreach ($required_keys as $key) {
            if (!isset($data[$key])) {
                throw new Exception("Missing required encryption data: {$key}");
            }
        }
        
        if ($data['version'] != 1) {
            throw new Exception("Unsupported encryption version: {$data['version']}");
        }
    }
    
    /**
     * Log encryption/decryption errors
     * 
     * @param string $message Error message to log
     */
    private function log_error($message) {
        if (defined('WP_DEBUG') && WP_DEBUG) {
            error_log("Journal Encryption Error: {$message}");
        }
    }
    
    /**
     * Check if a string is encrypted
     * 
     * @param mixed $data Data to check
     * @return boolean True if data appears to be encrypted
     */
    public function is_encrypted($data) {
        if (!is_array($data)) {
            return false;
        }
        
        $required_keys = array('data', 'iv', 'hmac', 'version');
        foreach ($required_keys as $key) {
            if (!isset($data[$key])) {
                return false;
            }
        }
        
        return true;
    }
}
