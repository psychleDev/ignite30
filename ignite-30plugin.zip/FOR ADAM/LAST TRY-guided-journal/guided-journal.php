<?php
/**
 * Plugin Name: 30 Day Guided Journal with Circle SSO
 * Plugin URI: https://example.com/guided-journal
 * Description: A guided journaling system with Circle Community integration
 * Version: 1.0.0
 * Requires at least: 5.8
 * Requires PHP: 7.4
 * Author: Your Name
 * License: GPL v2 or later
 * Text Domain: guided-journal
 */

// If this file is called directly, abort.
if (!defined('ABSPATH')) {
    die('Direct access is not allowed.');
}

// Define plugin constants
define('JOURNAL_PLUGIN_VERSION', '1.0.0');
define('JOURNAL_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('JOURNAL_PLUGIN_URL', plugin_dir_url(__FILE__));
define('JOURNAL_PLUGIN_BASENAME', plugin_basename(__FILE__));

/**
 * The code that runs during plugin activation.
 */
function activate_journal_plugin() {
    require_once JOURNAL_PLUGIN_DIR . 'includes/class-journal-activator.php';
    Journal_Activator::activate();
}

/**
 * The code that runs during plugin deactivation.
 */
function deactivate_journal_plugin() {
    require_once JOURNAL_PLUGIN_DIR . 'includes/class-journal-deactivator.php';
    Journal_Deactivator::deactivate();
}

register_activation_hook(__FILE__, 'activate_journal_plugin');
register_deactivation_hook(__FILE__, 'deactivate_journal_plugin');

/**
 * Load all required files
 */
function journal_load_dependencies() {
    // Core classes
    require_once JOURNAL_PLUGIN_DIR . 'includes/class-journal-encryption.php';
    require_once JOURNAL_PLUGIN_DIR . 'includes/class-journal-database.php';
    require_once JOURNAL_PLUGIN_DIR . 'includes/class-circle-sso.php';
    require_once JOURNAL_PLUGIN_DIR . 'includes/class-journal-privacy.php';
    
    // Admin specific
    if (is_admin()) {
        require_once JOURNAL_PLUGIN_DIR . 'admin/class-journal-admin.php';
    }
}

/**
 * Initialize the plugin
 */
function journal_init() {
    // Load dependencies
    journal_load_dependencies();
    
    // Initialize classes
    if (is_admin()) {
        new Journal_Admin();
    }
    
    // Initialize core functionality
    try {
        $database = new Journal_Database();
        $circle_sso = new Circle_SSO();
        $privacy = new Journal_Privacy();
    } catch (Exception $e) {
        add_action('admin_notices', function() use ($e) {
            $message = sprintf(__('Journal Plugin Error: %s', 'guided-journal'), $e->getMessage());
            printf('<div class="error"><p>%s</p></div>', esc_html($message));
        });
        return;
    }
}

/**
 * Initialize plugin when WordPress loads
 */
add_action('plugins_loaded', 'journal_init');

/**
 * Register the shortcode
 */
function journal_shortcode($atts = [], $content = null) {
    // Enqueue necessary scripts and styles
    wp_enqueue_style('journal-styles', JOURNAL_PLUGIN_URL . 'assets/css/styles.css', array(), JOURNAL_PLUGIN_VERSION);
    wp_enqueue_script('journal-script', JOURNAL_PLUGIN_URL . 'assets/js/journal.js', array('jquery'), JOURNAL_PLUGIN_VERSION, true);
    
    // Add AJAX data
    wp_localize_script('journal-script', 'journalAjax', array(
        'ajaxurl' => admin_url('admin-ajax.php'),
        'nonce' => wp_create_nonce('journal_nonce')
    ));
    
    // Include and return template
    ob_start();
    include JOURNAL_PLUGIN_DIR . 'templates/journal-interface.php';
    return ob_get_clean();
}
add_shortcode('guided_journal', 'journal_shortcode');
