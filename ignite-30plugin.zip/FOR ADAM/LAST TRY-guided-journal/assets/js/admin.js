/**
 * Journal Admin Interface JavaScript
 * Handles all admin-side functionality and interactions
 */

jQuery(document).ready(function($) {
    // Chart.js configuration
    Chart.defaults.color = '#ffffff';
    Chart.defaults.font.family = "'Montserrat', sans-serif";
    
    const charts = {};
    
    /**
     * Initialize admin interface
     */
    function initAdmin() {
        bindEventHandlers();
        initCharts();
        initDataTables();
        initSortable();
        
        // Load initial data
        loadStatistics();
    }
    
    /**
     * Bind event handlers
     */
    function bindEventHandlers() {
        // Settings form validation
        $('#journal-settings-form').on('submit', validateSettings);
        
        // Circle connection test
        $('#test-circle-connection').on('click', testCircleConnection);
        
        // Bulk actions
        $('.bulk-action-apply').on('click', handleBulkAction);
        
        // Prompt management
        $('#add-prompt').on('click', addPromptField);
        $('.remove-prompt').on('click', removePrompt);
        $('#reorder-prompts').on('click', togglePromptReordering);
        
        // Export/Import
        $('#export-settings').on('click', exportSettings);
        $('#import-settings').on('change', importSettings);
        
        // User management
        $('.delete-user-data').on('click', confirmDeleteUserData);
        $('.export-user-data').on('click', exportUserData);
        
        // Tab switching
        $('.nav-tab').on('click', switchTab);
        
        // Date range picker
        $('#date-range').daterangepicker({
            ranges: {
                'Today': [moment(), moment()],
                'Yesterday': [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
                'Last 7 Days': [moment().subtract(6, 'days'), moment()],
                'Last 30 Days': [moment().subtract(29, 'days'), moment()],
                'This Month': [moment().startOf('month'), moment().endOf('month')],
                'Last Month': [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')]
            }
        }, function(start, end) {
            loadStatistics(start.format('YYYY-MM-DD'), end.format('YYYY-MM-DD'));
        });
    }
    
    /**
     * Initialize statistics charts
     */
    function initCharts() {
        // Entries over time chart
        charts.entries = new Chart($('#entriesChart'), {
            type: 'line',
            data: {
                labels: [],
                datasets: [{
                    label: 'Daily Entries',
                    data: [],
                    borderColor: '#8e1010',
                    backgroundColor: 'rgba(142, 16, 16, 0.1)',
                    tension: 0.4
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'top'
                    },
                    title: {
                        display: true,
                        text: 'Entries Over Time'
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            precision: 0
                        }
                    }
                }
            }
        });
        
        // Entry visibility distribution chart
        charts.visibility = new Chart($('#visibilityChart'), {
            type: 'doughnut',
            data: {
                labels: ['Private', 'Community', 'Public'],
                datasets: [{
                    data: [],
                    backgroundColor: [
                        '#8e1010',
                        '#2a2a2a',
                        '#4a4a4a'
                    ]
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'top'
                    },
                    title: {
                        display: true,
                        text: 'Entry Privacy Distribution'
                    }
                }
            }
        });
        
        // User engagement chart
        charts.engagement = new Chart($('#engagementChart'), {
            type: 'bar',
            data: {
                labels: [],
                datasets: [{
                    label: 'Active Users',
                    data: [],
                    backgroundColor: '#8e1010'
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'top'
                    },
                    title: {
                        display: true,
                        text: 'User Engagement'
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            precision: 0
                        }
                    }
                }
            }
        });
    }
    
    /**
     * Initialize DataTables
     */
    function initDataTables() {
        $('.journal-table').DataTable({
            pageLength: 25,
            responsive: true,
            dom: 'Bfrtip',
            buttons: [
                'copy', 'csv', 'excel', 'pdf', 'print'
            ],
            order: [[0, 'desc']],
            language: {
                search: "_INPUT_",
                searchPlaceholder: "Search..."
            }
        });
    }
    
    /**
     * Initialize sortable prompts
     */
    function initSortable() {
        $('.prompts-list').sortable({
            handle: '.prompt-handle',
            update: function(event, ui) {
                updatePromptOrder();
            }
        });
    }
    
    /**
     * Load statistics
     */
    async function loadStatistics(startDate, endDate) {
        try {
            const response = await $.ajax({
                url: ajaxurl,
                type: 'POST',
                data: {
                    action: 'get_journal_statistics',
                    nonce: journalAdmin.nonce,
                    start_date: startDate,
                    end_date: endDate
                }
            });
            
            if (response.success) {
                updateStatistics(response.data);
            }
        } catch (error) {
            showNotice('Failed to load statistics', 'error');
        }
    }
    
    /**
     * Update statistics display
     */
    function updateStatistics(data) {
        // Update summary cards
        $('.stat-total-users').text(data.total_users);
        $('.stat-total-entries').text(data.total_entries);
        $('.stat-active-users').text(data.active_users);
        $('.stat-completion-rate').text(data.completion_rate + '%');
        
        // Update charts
        updateEntriesChart(data.entries_over_time);
        updateVisibilityChart(data.visibility_distribution);
        updateEngagementChart(data.user_engagement);
    }
    
    /**
     * Update entries chart
     */
    function updateEntriesChart(data) {
        charts.entries.data.labels = data.labels;
        charts.entries.data.datasets[0].data = data.values;
        charts.entries.update();
    }
    
    /**
     * Update visibility chart
     */
    function updateVisibilityChart(data) {
        charts.visibility.data.datasets[0].data = [
            data.private,
            data.community,
            data.public
        ];
        charts.visibility.update();
    }
    
    /**
     * Update engagement chart
     */
    function updateEngagementChart(data) {
        charts.engagement.data.labels = data.labels;
        charts.engagement.data.datasets[0].data = data.values;
        charts.engagement.update();
    }
    
    /**
     * Test Circle connection
     */
    async function testCircleConnection() {
        const $button = $('#test-circle-connection');
        const $spinner = $button.next('.spinner');
        const $result = $('#test-result');
        
        $button.prop('disabled', true);
        $spinner.addClass('is-active');
        
        try {
            const response = await $.ajax({
                url: ajaxurl,
                type: 'POST',
                data: {
                    action: 'test_circle_connection',
                    nonce: journalAdmin.nonce,
                    client_id: $('#circle_client_id').val(),
                    client_secret: $('#circle_client_secret').val(),
                    community_url: $('#circle_community_url').val()
                }
            });
            
            if (response.success) {
                $result.html('<div class="notice notice-success">Connection successful!</div>');
            } else {
                $result.html('<div class="notice notice-error">Connection failed: ' + response.data + '</div>');
            }
        } catch (error) {
            $result.html('<div class="notice notice-error">Connection failed: ' + error.message + '</div>');
        } finally {
            $button.prop('disabled', false);
            $spinner.removeClass('is-active');
        }
    }
    
    /**
     * Handle bulk actions
     */
    async function handleBulkAction(e) {
        e.preventDefault();
        
        const action = $('#bulk-action-selector').val();
        const selectedItems = $('.bulk-select:checked').map(function() {
            return $(this).val();
        }).get();
        
        if (action === '-1' || selectedItems.length === 0) {
            return;
        }
        
        if (!confirm('Are you sure you want to ' + action + ' the selected items?')) {
            return;
        }
        
        try {
            const response = await $.ajax({
                url: ajaxurl,
                type: 'POST',
                data: {
                    action: 'bulk_' + action + '_journal',
                    nonce: journalAdmin.nonce,
                    items: selectedItems
                }
            });
            
            if (response.success) {
                showNotice('Bulk action completed successfully', 'success');
                location.reload();
            } else {
                showNotice('Bulk action failed: ' + response.data, 'error');
            }
        } catch (error) {
            showNotice('Bulk action failed: ' + error.message, 'error');
        }
    }
    
    /**
     * Prompt management functions
     */
    function addPromptField() {
        const index = $('.prompt-field').length + 1;
        const template = `
            <div class="prompt-field">
                <span class="prompt-handle">↕️</span>
                <input type="text" name="journal_prompts[]" value="">
                <button type="button" class="remove-prompt">×</button>
            </div>
        `;
        $('.prompts-list').append(template);
    }
    
    function removePrompt() {
        $(this).closest('.prompt-field').remove();
        updatePromptOrder();
    }
    
    function updatePromptOrder() {
        const prompts = $('.prompt-field input').map(function() {
            return $(this).val();
        }).get();
        
        $('#prompts_order').val(JSON.stringify(prompts));
    }
    
    /**
     * Settings export/import
     */
    function exportSettings() {
        const settings = {
            circle_client_id: $('#circle_client_id').val(),
            circle_client_secret: $('#circle_client_secret').val(),
            circle_community_url: $('#circle_community_url').val(),
            journal_settings: JSON.parse($('#journal_settings').val()),
            journal_prompts: JSON.parse($('#prompts_order').val())
        };
        
        const blob = new Blob([JSON.stringify(settings, null, 2)], {type: 'application/json'});
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = 'journal-settings.json';
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
    }
    
    function importSettings(e) {
        const file = e.target.files[0];
        if (!file) return;
        
        const reader = new FileReader();
        reader.onload = function(e) {
            try {
                const settings = JSON.parse(e.target.result);
                
                // Validate settings format
                if (!validateSettingsFormat(settings)) {
                    throw new Error('Invalid settings format');
                }
                
                // Apply settings
                $('#circle_client_id').val(settings.circle_client_id);
                $('#circle_client_secret').val(settings.circle_client_secret);
                $('#circle_community_url').val(settings.circle_community_url);
                $('#journal_settings').val(JSON.stringify(settings.journal_settings));
                
                // Rebuild prompts list
                $('.prompts-list').empty();
                settings.journal_prompts.forEach(prompt => {
                    $('.prompts-list').append(`
                        <div class="prompt-field">
                            <span class="prompt-handle">↕️</span>
                            <input type="text" name="journal_prompts[]" value="${prompt}">
                            <button type="button" class="remove-prompt">×</button>
                        </div>
                    `);
                });
                
                showNotice('Settings imported successfully', 'success');
            } catch (error) {
                showNotice('Failed to import settings: ' + error.message, 'error');
            }
        };
        reader.readAsText(file);
    }
    
    /**
     * Utility functions
     */
    function showNotice(message, type = 'info') {
        const notice = $(`<div class="notice notice-${type} is-dismissible"><p>${message}</p></div>`);
        $('.wrap h1').after(notice);
        
        setTimeout(() => {
            notice.fadeOut(() => notice.remove());
        }, 5000);
    }
    
    function validateSettings() {
        // Add your validation logic here
        return true;
    }
    
    function validateSettingsFormat(settings) {
        const required = ['circle_client_id', 'circle_client_secret', 'circle_community_url', 'journal_settings', 'journal_prompts'];
        return required.every(key => key in settings);
    }
    
    function switchTab(e) {
        e.preventDefault();
        
        const $tab = $(this);
        const target = $tab.data('tab');
        
        // Update URL without reload
        const url = new URL(window.location);
        url.searchParams.set('tab', target);
        window.history.pushState({}, '', url);
        
        // Switch tabs
        $('.nav-tab').removeClass('nav-tab-active');
        $tab.addClass('nav-tab-active');
        
        // Switch content
        $('.tab-content').hide();
        $('#' + target).show();
    }
    
    // Initialize everything
    initAdmin();
});
