/**
 * Journal Interface JavaScript
 * Handles all client-side functionality for the journal interface
 */

jQuery(document).ready(function($) {
    // Constants
    const AUTOSAVE_INTERVAL = 60000; // 1 minute
    const WORD_COUNT_MIN = 0;
    const WORD_COUNT_MAX = 0;
    
    // State management
    let currentDay = 1;
    let hasUnsavedChanges = false;
    let originalContent = '';
    let autoSaveTimer = null;
    let pendingNavigation = null;
    
    // Cache DOM elements
    const $gridView = $('#gridView');
    const $journalView = $('#journalView');
    const $journalEntry = $('#journalEntry');
    const $entryVisibility = $('#entryVisibility');
    const $saveButton = $('#saveEntry');
    const $savingIndicator = $('#savingIndicator');
    const $confirmationModal = $('#confirmationModal');
    const $progressModal = $('#progressModal');
    
    // Journal prompts
    const prompts = [
        "What are three things you're grateful for today and why?",
        "Describe a challenge you're currently facing and how you plan to overcome it.",
        "What's a skill you'd like to develop and what steps can you take to learn it?",
        "Reflect on a recent accomplishment and how it made you feel.",
        "Write about someone who's positively influenced your life and why.",
        "What are your top three priorities for the next month?",
        "Describe your ideal day from start to finish.",
        "What's a fear you'd like to overcome and why?",
        "Write about a place that makes you feel peaceful.",
        "What's a habit you'd like to build or break?",
        "Reflect on a mistake you've learned from.",
        "What are your favorite ways to practice self-care?",
        "Write about a goal you're working toward.",
        "What makes you feel most alive?",
        "Describe a memory that always makes you smile.",
        "What are your core values and how do they guide your decisions?",
        "Write about something you're looking forward to.",
        "What's a recent situation you wish you had handled differently?",
        "Describe your perfect weekend.",
        "What are you most proud of about yourself?",
        "Write about a book, movie, or song that deeply moved you.",
        "What does success mean to you?",
        "Describe a relationship you'd like to improve and how.",
        "What are your favorite ways to recharge when feeling drained?",
        "Write about a dream or aspiration you haven't shared with others.",
        "What are three things you like about your personality?",
        "Describe a recent act of kindness you witnessed or performed.",
        "What would you do if you knew you couldn't fail?",
        "Write about something you're curious to learn more about.",
        "Reflect on your journey over the past month and what you've learned."
    ];
    
    /**
     * Initialize journal interface
     */
    function initJournal() {
        bindEventHandlers();
        initAutoSave();
        loadUserProgress();
        updateWordCount();
        
        // Handle URL parameters for direct day access
        const urlParams = new URLSearchParams(window.location.search);
        const dayParam = urlParams.get('day');
        if (dayParam) {
            navigateToDay(parseInt(dayParam));
        }
    }
    
    /**
     * Bind event handlers
     */
    function bindEventHandlers() {
        // Grid view handlers
        $('.prompt-card').click(function(e) {
            e.preventDefault();
            const newDay = $(this).data('day');
            if ($(this).hasClass('locked')) {
                showMessage('Complete previous days first!', 'warning');
                return;
            }
            handleDayNavigation(newDay);
        });
        
        // Navigation handlers
        $('#prevDay').click(() => handleDayNavigation(currentDay - 1));
        $('#nextDay').click(() => handleDayNavigation(currentDay + 1));
        $saveButton.click(saveEntry);
        
        // Content change handlers
        $journalEntry.on('input', function() {
            hasUnsavedChanges = $(this).val() !== originalContent;
            updateSaveButton();
            updateWordCount();
        });
        
        // View toggles
        $('.contents-toggle').click(() => handleViewChange('grid'));
        $('.list-toggle').click(toggleEntriesList);
        
        // Privacy control
        $entryVisibility.change(function() {
            if ($(this).val() === 'private') {
                showPrivacyNotice();
            }
            hasUnsavedChanges = true;
            updateSaveButton();
        });
        
        // Writing tools
        $('.tool-button').click(function() {
            const tool = $(this).data('tool');
            applyFormatting(tool);
        });
        
        // Modal handlers
        $('#saveAndContinue').click(async function() {
            const saved = await saveEntry();
            if (saved) {
                executePendingNavigation();
            }
        });
        
        $('#discardAndContinue').click(function() {
            hasUnsavedChanges = false;
            executePendingNavigation();
        });
        
        $('#cancelNavigation').click(hideConfirmationModal);
        
        // Progress view
        $('.view-progress-btn').click(showProgressModal);
        $('.modal-close').click(hideModals);
        
        // Window events
        $(window).on('beforeunload', function(e) {
            if (hasUnsavedChanges) {
                e.preventDefault();
                return '';
            }
        });
    }
    
    /**
     * Initialize auto-save functionality
     */
    function initAutoSave() {
        if (AUTOSAVE_INTERVAL > 0) {
            $journalEntry.on('input', function() {
                clearTimeout(autoSaveTimer);
                autoSaveTimer = setTimeout(function() {
                    if (hasUnsavedChanges) {
                        saveEntry(true); // true for autosave
                    }
                }, AUTOSAVE_INTERVAL);
            });
        }
    }
    
    /**
     * Handle day navigation
     */
    async function handleDayNavigation(newDay) {
        if (newDay < 1 || newDay > 30) return;
        
        if (hasUnsavedChanges) {
            showConfirmationModal(newDay);
        } else {
            await navigateToDay(newDay);
        }
    }
    
    /**
     * Navigate to specific day
     */
    async function navigateToDay(day) {
        currentDay = day;
        
        // Update UI
        $('#dayTitle').text(`Day ${day}`);
        $('#promptText').text(prompts[day - 1]);
        
        try {
            const entry = await loadEntry(day);
            $journalEntry.val(entry ? entry.entry_content : '');
            $entryVisibility.val(entry ? entry.visibility : 'private');
            
            originalContent = $journalEntry.val();
            hasUnsavedChanges = false;
            updateSaveButton();
            updateWordCount();
            
            // Update view
            $gridView.hide();
            $journalView.show();
            
            // Update URL without reloading
            const newUrl = new URL(window.location);
            newUrl.searchParams.set('day', day);
            window.history.pushState({}, '', newUrl);
            
            // Scroll to top
            window.scrollTo(0, 0);
            
        } catch (error) {
            showMessage('Failed to load entry', 'error');
        }
    }
    
    /**
     * Save journal entry
     */
    async function saveEntry(isAutosave = false) {
        const entryContent = $journalEntry.val();
        const wordCount = countWords(entryContent);
        
        // Validate word count if limits are set
        if (WORD_COUNT_MIN > 0 && wordCount < WORD_COUNT_MIN) {
            showMessage(`Please write at least ${WORD_COUNT_MIN} words`, 'warning');
            return false;
        }
        
        if (WORD_COUNT_MAX > 0 && wordCount > WORD_COUNT_MAX) {
            showMessage(`Please keep your entry under ${WORD_COUNT_MAX} words`, 'warning');
            return false;
        }
        
        if (!isAutosave) {
            $savingIndicator.addClass('active');
        }
        
        try {
            const response = await $.ajax({
                url: journalAjax.ajaxurl,
                type: 'POST',
                data: {
                    action: 'save_journal_entry',
                    nonce: journalAjax.nonce,
                    day_number: currentDay,
                    entry_content: entryContent,
                    visibility: $entryVisibility.val()
                }
            });
            
            if (response.success) {
                hasUnsavedChanges = false;
                originalContent = entryContent;
                updateSaveButton();
                updateLastSaved();
                
                if (!isAutosave) {
                    showMessage('Entry saved successfully', 'success');
                    updateUserProgress();
                }
                
                return true;
            } else {
                throw new Error(response.data || 'Save failed');
            }
        } catch (error) {
            if (!isAutosave) {
                showMessage(error.message, 'error');
            }
            return false;
        } finally {
            if (!isAutosave) {
                $savingIndicator.removeClass('active');
            }
        }
    }
    
    /**
     * Load entry for specific day
     */
    async function loadEntry(day) {
        const response = await $.ajax({
            url: journalAjax.ajaxurl,
            type: 'POST',
            data: {
                action: 'get_journal_entry',
                nonce: journalAjax.nonce,
                day_number: day
            }
        });
        
        return response.success ? response.data : null;
    }
    
    /**
     * Update user progress
     */
    async function updateUserProgress() {
        try {
            const response = await $.ajax({
                url: journalAjax.ajaxurl,
                type: 'POST',
                data: {
                    action: 'get_user_progress',
                    nonce: journalAjax.nonce
                }
            });
            
            if (response.success) {
                updateProgressUI(response.data);
            }
        } catch (error) {
            console.error('Failed to update progress:', error);
        }
    }
    
    /**
     * Update progress UI
     */
    function updateProgressUI(progress) {
        // Update completion markers
        $('.prompt-card').each(function() {
            const day = $(this).data('day');
            $(this).toggleClass('completed', progress.completed_days.includes(day));
        });
        
        // Update streak
        if (progress.current_streak > 0) {
            $('.user-streak').text(`🔥 ${progress.current_streak} day streak!`);
        }
        
        // Update progress modal
        $('#completedEntries').text(`${progress.completed_days.length}/30`);
        $('#currentStreak').text(progress.current_streak);
        $('#bestStreak').text(progress.best_streak);
    }
    
    /**
     * Show/hide entries list
     */
    function toggleEntriesList() {
        const $list = $('#entriesList');
        
        if (!$list.hasClass('active')) {
            loadEntries().then(entries => {
                renderEntriesList(entries);
                $list.addClass('active');
            });
        } else {
            $list.removeClass('active');
        }
    }
    
    /**
     * Load all entries
     */
    async function loadEntries() {
        const response = await $.ajax({
            url: journalAjax.ajaxurl,
            type: 'POST',
            data: {
                action: 'get_journal_entries',
                nonce: journalAjax.nonce
            }
        });
        
        return response.success ? response.data : [];
    }
    
    /**
     * Render entries list
     */
    function renderEntriesList(entries) {
        const $content = $('.entries-content');
        $content.empty();
        
        entries.forEach(entry => {
            const $item = $(`
                <div class="entry-item" data-day="${entry.day_number}">
                    <div class="entry-header">
                        <span class="entry-day">Day ${entry.day_number}</span>
                        <span class="entry-date">${formatDate(entry.created_at)}</span>
                    </div>
                    <div class="entry-preview">${truncateText(entry.entry_content, 100)}</div>
                    <span class="entry-visibility ${entry.visibility}">${entry.visibility}</span>
                </div>
            `);
            
            $item.click(() => handleDayNavigation(entry.day_number));
            $content.append($item);
        });
    }
    
    /**
     * Modal handling
     */
    function showConfirmationModal(destination) {
        pendingNavigation = destination;
        $confirmationModal.addClass('active');
    }
    
    function hideConfirmationModal() {
        $confirmationModal.removeClass('active');
        pendingNavigation = null;
    }
    
    function executePendingNavigation() {
        hideConfirmationModal();
        
        if (pendingNavigation === 'grid') {
            $journalView.hide();
            $gridView.show();
        } else if (typeof pendingNavigation === 'number') {
            navigateToDay(pendingNavigation);
        }
    }
    
    /**
     * Utility functions
     */
    function updateWordCount() {
        const words = countWords($journalEntry.val());
        $('.word-count span').text(words);
    }
    
    function countWords(text) {
        return text.trim().split(/\s+/).filter(Boolean).length;
    }
    
    function updateSaveButton() {
        $saveButton.prop('disabled', !hasUnsavedChanges);
        $saveButton.toggleClass('unsaved', hasUnsavedChanges);
    }
    
    function updateLastSaved() {
        $('.save-time').text(formatDate(new Date()));
    }
    
    function formatDate(date) {
        date = new Date(date);
        return date.toLocaleString();
    }
    
    function truncateText(text, length) {
        text = text.replace(/<[^>]*>/g, '');
        return text.length > length ? text.substring(0, length) + '...' : text;
    }
    
    function showMessage(message, type = 'info') {
        const $status = $('.sync-status');
        $status.text(message)
            .removeClass('success error warning info')
            .addClass(type)
            .fadeIn();
        
        setTimeout(() => {
            $status.fadeOut(() => {
                $status.removeClass(type);
            });
        }, type === 'error' ? 5000 : 3000);
    }
    
    function showPrivacyNotice() {
        if (!localStorage.getItem('privacy_notice_shown')) {
            showMessage('Private entries are encrypted and can only be accessed by you', 'info');
            localStorage.setItem('privacy_notice_shown', 'true');
        }
    }
    
    /**
     * Text formatting
     */
    function applyFormatting(tool) {
        const $textarea = $journalEntry[0];
        const start = $textarea.selectionStart;
        const end = $textarea.selectionEnd;
        const text = $textarea.value;
        let formattedText;
        let selectStart = start;
        let selectEnd = end;
        
        switch (tool) {
            case 'bold':
                formattedText = `**${text.substring(start, end)}**`;
                selectEnd = end + 4;
                break;
                
            case 'italic':
                formattedText = `_${text.substring(start, end)}_`;
                selectEnd = end + 2;
                break;
                
            case 'list':
                formattedText = text.substring(start, end).split('\n')
                    .map(line => `- ${line}`)
                    .join('\n');
                selectEnd = end + (formattedText.length - (end - start));
                break;
        }
        
        $textarea.value = text.substring(0, start) + formattedText + text.substring(end);
        $textarea.focus();
        $textarea.setSelectionRange(selectStart, selectEnd);
        
        // Trigger change event
        $journalEntry.trigger('input');
    }
    
    /**
     * Progress calendar functionality
     */
    function initProgressCalendar() {
        const $calendar = $('.progress-calendar');
        const currentDate = new Date();
        const firstDay = new Date(currentDate.getFullYear(), currentDate.getMonth(), 1);
        const lastDay = new Date(currentDate.getFullYear(), currentDate.getMonth() + 1, 0);
        
        let calendarHtml = `
            <div class="calendar-header">
                <h4>${currentDate.toLocaleString('default', { month: 'long' })} ${currentDate.getFullYear()}</h4>
            </div>
            <div class="calendar-grid">
                <div class="calendar-weekdays">
                    ${['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat']
                        .map(day => `<div class="weekday">${day}</div>`)
                        .join('')}
                </div>
                <div class="calendar-days">
        `;
        
        // Add empty cells for days before first of month
        for (let i = 0; i < firstDay.getDay(); i++) {
            calendarHtml += '<div class="calendar-day empty"></div>';
        }
        
        // Add days of month
        for (let day = 1; day <= lastDay.getDate(); day++) {
            const date = new Date(currentDate.getFullYear(), currentDate.getMonth(), day);
            const classes = ['calendar-day'];
            
            if (date.toDateString() === currentDate.toDateString()) {
                classes.push('today');
            }
            
            calendarHtml += `
                <div class="${classes.join(' ')}" data-date="${date.toISOString()}">
                    ${day}
                </div>
            `;
        }
        
        calendarHtml += '</div></div>';
        $calendar.html(calendarHtml);
    }
    
    /**
     * Update calendar with entry data
     */
    function updateCalendar(entries) {
        $('.calendar-day').each(function() {
            const dayDate = new Date($(this).data('date'));
            if (!dayDate) return;
            
            const entry = entries.find(e => {
                const entryDate = new Date(e.created_at);
                return entryDate.toDateString() === dayDate.toDateString();
            });
            
            if (entry) {
                $(this).addClass('has-entry');
                $(this).attr('title', `Day ${entry.day_number}`);
            }
        });
    }
    
    /**
     * Show progress modal with statistics
     */
    function showProgressModal() {
        initProgressCalendar();
        loadEntries().then(entries => {
            updateCalendar(entries);
            $progressModal.addClass('active');
        });
    }
    
    /**
     * Hide all modals
     */
    function hideModals() {
        $('.modal').removeClass('active');
    }
    
    /**
     * Handle keyboard shortcuts
     */
    function initKeyboardShortcuts() {
        $(document).on('keydown', function(e) {
            // Cmd/Ctrl + S to save
            if ((e.metaKey || e.ctrlKey) && e.key === 's') {
                e.preventDefault();
                if (!$saveButton.prop('disabled')) {
                    saveEntry();
                }
            }
            
            // Esc to close modals
            if (e.key === 'Escape') {
                hideModals();
            }
        });
    }
    
    /**
     * Load user progress
     */
    async function loadUserProgress() {
        try {
            const response = await $.ajax({
                url: journalAjax.ajaxurl,
                type: 'POST',
                data: {
                    action: 'get_user_progress',
                    nonce: journalAjax.nonce
                }
            });
            
            if (response.success) {
                updateProgressUI(response.data);
                
                // Set current day if not already set
                if (!currentDay) {
                    currentDay = Math.min(response.data.completed_days.length + 1, 30);
                }
            }
        } catch (error) {
            console.error('Failed to load progress:', error);
            showMessage('Failed to load progress', 'error');
        }
    }
    
    /**
     * Check Circle SSO session
     */
    async function checkCircleSession() {
        try {
            const response = await $.ajax({
                url: journalAjax.ajaxurl,
                type: 'POST',
                data: {
                    action: 'verify_circle_session',
                    nonce: journalAjax.nonce
                }
            });
            
            if (!response.success) {
                window.location.reload();
            }
        } catch (error) {
            console.error('Session check failed:', error);
        }
    }
    
    /**
     * Initialize periodic session check
     */
    function initSessionCheck() {
        setInterval(checkCircleSession, 5 * 60 * 1000); // Check every 5 minutes
    }
    
    /**
     * Initialize everything
     */
    function init() {
        initJournal();
        initKeyboardShortcuts();
        initSessionCheck();
        
        // Handle initial view
        const urlParams = new URLSearchParams(window.location.search);
        if (urlParams.has('day')) {
            navigateToDay(parseInt(urlParams.get('day')));
        }
    }
    
    // Start the application
    init();
});