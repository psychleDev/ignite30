<?php
/**
 * Journal Admin Handler
 * 
 * Manages all administrative functionality including settings,
 * user management, and admin dashboards.
 */

class Journal_Admin {
    private $settings_page = 'journal-settings';
    private $option_group = 'journal_settings_group';
    
    /**
     * Initialize admin functionality
     */
    public function __construct() {
        // Add admin menu and settings
        add_action('admin_menu', array($this, 'add_admin_menu'));
        add_action('admin_init', array($this, 'register_settings'));
        
        // Add admin notices
        add_action('admin_notices', array($this, 'display_admin_notices'));
        
        // Add dashboard widgets
        add_action('wp_dashboard_setup', array($this, 'add_dashboard_widgets'));
        
        // Add admin scripts and styles
        add_action('admin_enqueue_scripts', array($this, 'enqueue_admin_assets'));
        
        // Add plugin action links
        add_filter('plugin_action_links_guided-journal/guided-journal.php', 
            array($this, 'add_plugin_action_links')
        );
        
        // Add meta box to user profile
        add_action('show_user_profile', array($this, 'add_user_journal_stats'));
        add_action('edit_user_profile', array($this, 'add_user_journal_stats'));
    }
    
    /**
     * Add admin menu items
     */
    public function add_admin_menu() {
        add_menu_page(
            __('Journal Settings', 'guided-journal'),
            __('Journal', 'guided-journal'),
            'manage_options',
            $this->settings_page,
            array($this, 'render_settings_page'),
            'dashicons-book-alt',
            30
        );
        
        add_submenu_page(
            $this->settings_page,
            __('Journal Settings', 'guided-journal'),
            __('Settings', 'guided-journal'),
            'manage_options',
            $this->settings_page
        );
        
        add_submenu_page(
            $this->settings_page,
            __('Journal Statistics', 'guided-journal'),
            __('Statistics', 'guided-journal'),
            'manage_options',
            'journal-statistics',
            array($this, 'render_statistics_page')
        );
        
        add_submenu_page(
            $this->settings_page,
            __('Journal User Management', 'guided-journal'),
            __('Users', 'guided-journal'),
            'manage_options',
            'journal-users',
            array($this, 'render_users_page')
        );
    }
    
    /**
     * Register plugin settings
     */
    public function register_settings() {
        register_setting(
            $this->option_group,
            'circle_client_id',
            array('sanitize_callback' => 'sanitize_text_field')
        );
        
        register_setting(
            $this->option_group,
            'circle_client_secret',
            array('sanitize_callback' => 'sanitize_text_field')
        );
        
        register_setting(
            $this->option_group,
            'circle_community_url',
            array('sanitize_callback' => 'esc_url_raw')
        );
        
        register_setting(
            $this->option_group,
            'journal_settings',
            array(
                'sanitize_callback' => array($this, 'sanitize_journal_settings'),
                'default' => array(
                    'auto_save_interval' => 60,
                    'min_word_count' => 0,
                    'max_word_count' => 0,
                    'allow_public_entries' => true,
                    'allow_community_entries' => true,
                    'backup_entries' => true,
                    'delete_data_on_uninstall' => false,
                    'encryption_enabled' => true
                )
            )
        );
        
        register_setting(
            $this->option_group,
            'journal_prompts',
            array('sanitize_callback' => array($this, 'sanitize_prompts'))
        );
        
        // Add settings sections
        add_settings_section(
            'circle_sso_section',
            __('Circle SSO Settings', 'guided-journal'),
            array($this, 'render_circle_section'),
            $this->settings_page
        );
        
        add_settings_section(
            'journal_general_section',
            __('General Settings', 'guided-journal'),
            array($this, 'render_general_section'),
            $this->settings_page
        );
        
        add_settings_section(
            'journal_privacy_section',
            __('Privacy Settings', 'guided-journal'),
            array($this, 'render_privacy_section'),
            $this->settings_page
        );
        
        add_settings_section(
            'journal_prompts_section',
            __('Journal Prompts', 'guided-journal'),
            array($this, 'render_prompts_section'),
            $this->settings_page
        );
        
        // Add settings fields
        $this->add_settings_fields();
    }
    
    /**
     * Add settings fields
     */
    private function add_settings_fields() {
        // Circle SSO fields
        add_settings_field(
            'circle_client_id',
            __('Client ID', 'guided-journal'),
            array($this, 'render_text_field'),
            $this->settings_page,
            'circle_sso_section',
            array(
                'label_for' => 'circle_client_id',
                'class' => 'circle-sso-field',
                'description' => __('Enter your Circle OAuth Client ID', 'guided-journal')
            )
        );
        
        add_settings_field(
            'circle_client_secret',
            __('Client Secret', 'guided-journal'),
            array($this, 'render_password_field'),
            $this->settings_page,
            'circle_sso_section',
            array(
                'label_for' => 'circle_client_secret',
                'class' => 'circle-sso-field',
                'description' => __('Enter your Circle OAuth Client Secret', 'guided-journal')
            )
        );
        
        add_settings_field(
            'circle_community_url',
            __('Community URL', 'guided-journal'),
            array($this, 'render_url_field'),
            $this->settings_page,
            'circle_sso_section',
            array(
                'label_for' => 'circle_community_url',
                'class' => 'circle-sso-field',
                'description' => __('Enter your Circle Community URL', 'guided-journal')
            )
        );
        
        // General settings fields
        add_settings_field(
            'auto_save_interval',
            __('Auto-save Interval', 'guided-journal'),
            array($this, 'render_number_field'),
            $this->settings_page,
            'journal_general_section',
            array(
                'label_for' => 'auto_save_interval',
                'class' => 'journal-setting-field',
                'description' => __('Interval in seconds between auto-saves (0 to disable)', 'guided-journal'),
                'min' => 0,
                'max' => 300
            )
        );
        
        add_settings_field(
            'word_count_limits',
            __('Word Count Limits', 'guided-journal'),
            array($this, 'render_word_count_fields'),
            $this->settings_page,
            'journal_general_section',
            array(
                'class' => 'journal-setting-field',
                'description' => __('Set minimum and maximum word counts (0 for no limit)', 'guided-journal')
            )
        );
        
        // Privacy settings fields
        add_settings_field(
            'visibility_options',
            __('Entry Visibility Options', 'guided-journal'),
            array($this, 'render_visibility_options'),
            $this->settings_page,
            'journal_privacy_section',
            array(
                'class' => 'journal-privacy-field'
            )
        );
        
        add_settings_field(
            'data_protection',
            __('Data Protection', 'guided-journal'),
            array($this, 'render_data_protection_options'),
            $this->settings_page,
            'journal_privacy_section',
            array(
                'class' => 'journal-privacy-field'
            )
        );
        
        // Prompts section fields
        add_settings_field(
            'journal_prompts',
            __('Daily Prompts', 'guided-journal'),
            array($this, 'render_prompts_editor'),
            $this->settings_page,
            'journal_prompts_section',
            array(
                'class' => 'journal-prompts-field'
            )
        );
    }
    
    /**
     * Render settings page
     */
    public function render_settings_page() {
        if (!current_user_can('manage_options')) {
            wp_die(__('You do not have sufficient permissions to access this page.'));
        }
        
        ?>
        <div class="wrap">
            <h1><?php echo esc_html(get_admin_page_title()); ?></h1>
            
            <?php
            $active_tab = isset($_GET['tab']) ? $_GET['tab'] : 'general';
            ?>
            
            <h2 class="nav-tab-wrapper">
                <a href="?page=<?php echo $this->settings_page; ?>&tab=general" 
                   class="nav-tab <?php echo $active_tab == 'general' ? 'nav-tab-active' : ''; ?>">
                    <?php _e('General', 'guided-journal'); ?>
                </a>
                <a href="?page=<?php echo $this->settings_page; ?>&tab=circle" 
                   class="nav-tab <?php echo $active_tab == 'circle' ? 'nav-tab-active' : ''; ?>">
                    <?php _e('Circle SSO', 'guided-journal'); ?>
                </a>
                <a href="?page=<?php echo $this->settings_page; ?>&tab=privacy" 
                   class="nav-tab <?php echo $active_tab == 'privacy' ? 'nav-tab-active' : ''; ?>">
                    <?php _e('Privacy', 'guided-journal'); ?>
                </a>
                <a href="?page=<?php echo $this->settings_page; ?>&tab=prompts" 
                   class="nav-tab <?php echo $active_tab == 'prompts' ? 'nav-tab-active' : ''; ?>">
                    <?php _e('Prompts', 'guided-journal'); ?>
                </a>
            </h2>
            
            <form action="options.php" method="post">
                <?php
                settings_fields($this->option_group);
                do_settings_sections($this->settings_page);
                submit_button();
                ?>
            </form>
            
            <?php if ($active_tab == 'circle'): ?>
                <div class="circle-test-connection">
                    <h3><?php _e('Test Circle Connection', 'guided-journal'); ?></h3>
                    <p><?php _e('Click the button below to test your Circle SSO configuration.', 'guided-journal'); ?></p>
                    <button type="button" class="button button-secondary" id="test-circle-connection">
                        <?php _e('Test Connection', 'guided-journal'); ?>
                    </button>
                    <span class="spinner"></span>
                    <div id="test-result"></div>
                </div>
            <?php endif; ?>
        </div>
        <?php
    }
    
    /**
     * Render statistics page
     */
    public function render_statistics_page() {
        if (!current_user_can('manage_options')) {
            wp_die(__('You do not have sufficient permissions to access this page.'));
        }
        
        // Get statistics
        global $wpdb;
        $stats = $this->get_journal_statistics();
        
        ?>
        <div class="wrap">
            <h1><?php _e('Journal Statistics', 'guided-journal'); ?></h1>
            
            <div class="journal-stats-wrapper">
                <div class="journal-stats-cards">
                    <div class="stats-card">
                        <h3><?php _e('Total Users', 'guided-journal'); ?></h3>
                        <div class="stats-number"><?php echo esc_html($stats['total_users']); ?></div>
                    </div>
                    
                    <div class="stats-card">
                        <h3><?php _e('Total Entries', 'guided-journal'); ?></h3>
                        <div class="stats-number"><?php echo esc_html($stats['total_entries']); ?></div>
                    </div>
                    
                    <div class="stats-card">
                        <h3><?php _e('Active Users (30 days)', 'guided-journal'); ?></h3>
                        <div class="stats-number"><?php echo esc_html($stats['active_users']); ?></div>
                    </div>
                    
                    <div class="stats-card">
                        <h3><?php _e('Completion Rate', 'guided-journal'); ?></h3>
                        <div class="stats-number"><?php echo esc_html($stats['completion_rate']); ?>%</div>
                    </div>
                </div>
                
                <div class="journal-stats-charts">
                    <div class="stats-chart">
                        <canvas id="entriesChart"></canvas>
                    </div>
                    
                    <div class="stats-chart">
                        <canvas id="visibilityChart"></canvas>
                    </div>
                </div>
                
                <div class="journal-stats-table">
                    <h3><?php _e('Top Users', 'guided-journal'); ?></h3>
                    <table class="wp-list-table widefat fixed striped">
                        <thead>
                            <tr>
                                <th><?php _e('User', 'guided-journal'); ?></th>
                                <th><?php _e('Entries', 'guided-journal'); ?></th>
                                <th><?php _e('Streak', 'guided-journal'); ?></th>
                                <th><?php _e('Last Entry', 'guided-journal'); ?></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($stats['top_users'] as $user): ?>
                                <tr>
                                    <td><?php echo esc_html($user->display_name); ?></td>
                                    <td><?php echo esc_html($user->total_entries); ?></td>
                                    <td><?php echo esc_html($user->streak_count); ?></td>
                                    <td><?php echo esc_html($user->last_entry_date); ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        <?php
    }
    
    /**
     * Render users page
     */
    public function render_users_page() {
        if (!current_user_can('manage_options')) {
            wp_die(__('You do not have sufficient permissions to access this page.'));
        }
        
        // Handle bulk actions
        if (isset($_POST['action']) && check_admin_referer('journal_users_action')) {

            $this->handle_bulk_actions($_POST['action'], $_POST['users'] ?? array());
        }
        
        // Get users with journal data
        $users = $this->get_journal_users();
        
        ?>
        <div class="wrap">
            <h1><?php _e('Journal Users', 'guided-journal'); ?></h1>
            
            <form method="post" action="">
                <?php wp_nonce_field('journal_users_action'); ?>
                
                <div class="tablenav top">
                    <div class="alignleft actions bulkactions">
                        <select name="action">
                            <option value="-1"><?php _e('Bulk Actions', 'guided-journal'); ?></option>
                            <option value="export"><?php _e('Export Data', 'guided-journal'); ?></option>
                            <option value="delete"><?php _e('Delete Data', 'guided-journal'); ?></option>
                            <option value="backup"><?php _e('Backup Data', 'guided-journal'); ?></option>
                        </select>
                        <input type="submit" class="button action" value="<?php esc_attr_e('Apply', 'guided-journal'); ?>">
                    </div>
                </div>
                
                <table class="wp-list-table widefat fixed striped">
                    <thead>
                        <tr>
                            <td class="manage-column column-cb check-column">
                                <input type="checkbox">
                            </td>
                            <th><?php _e('User', 'guided-journal'); ?></th>
                            <th><?php _e('Circle ID', 'guided-journal'); ?></th>
                            <th><?php _e('Entries', 'guided-journal'); ?></th>
                            <th><?php _e('Progress', 'guided-journal'); ?></th>
                            <th><?php _e('Last Active', 'guided-journal'); ?></th>
                            <th><?php _e('Actions', 'guided-journal'); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($users as $user): ?>
                            <tr>
                                <th scope="row" class="check-column">
                                    <input type="checkbox" name="users[]" value="<?php echo esc_attr($user->ID); ?>">
                                </th>
                                <td>
                                    <?php echo esc_html($user->display_name); ?>
                                    <br>
                                    <small><?php echo esc_html($user->user_email); ?></small>
                                </td>
                                <td><?php echo esc_html(get_user_meta($user->ID, 'circle_user_id', true)); ?></td>
                                <td><?php echo esc_html($user->total_entries); ?></td>
                                <td>
                                    <div class="progress-bar">
                                        <div class="progress" style="width: <?php echo esc_attr($user->completion_rate); ?>%">
                                            <?php echo esc_html($user->completion_rate); ?>%
                                        </div>
                                    </div>
                                </td>
                                <td><?php echo esc_html($user->last_active); ?></td>
                                <td>
                                    <div class="row-actions">
                                        <span class="view">
                                            <a href="<?php echo esc_url($this->get_user_entries_url($user->ID)); ?>">
                                                <?php _e('View Entries', 'guided-journal'); ?>
                                            </a> |
                                        </span>
                                        <span class="export">
                                            <a href="<?php echo esc_url($this->get_export_url($user->ID)); ?>">
                                                <?php _e('Export', 'guided-journal'); ?>
                                            </a> |
                                        </span>
                                        <span class="delete">
                                            <a href="<?php echo esc_url($this->get_delete_url($user->ID)); ?>" 
                                               class="delete-entries" 
                                               data-user="<?php echo esc_attr($user->display_name); ?>">
                                                <?php _e('Delete', 'guided-journal'); ?>
                                            </a>
                                        </span>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </form>
        </div>
        <?php
    }
    
    /**
     * Handle bulk actions for users
     */
    private function handle_bulk_actions($action, $users) {
        if (empty($users)) {
            return;
        }
        
        switch ($action) {
            case 'export':
                $this->bulk_export_users($users);
                break;
                
            case 'delete':
                $this->bulk_delete_users_data($users);
                break;
                
            case 'backup':
                $this->bulk_backup_users_data($users);
                break;
        }
    }
    
    /**
     * Bulk export users' journal data
     */
    private function bulk_export_users($users) {
        $filename = 'journal-export-' . date('Y-m-d') . '.zip';
        $temp_dir = get_temp_dir() . 'journal-export-' . time();
        
        if (!mkdir($temp_dir)) {
            add_settings_error(
                'journal_users',
                'export_failed',
                __('Failed to create temporary directory for export', 'guided-journal')
            );
            return;
        }
        
        foreach ($users as $user_id) {
            $user_data = $this->export_user_data($user_id);
            if ($user_data) {
                $user = get_userdata($user_id);
                $user_file = $temp_dir . '/' . sanitize_file_name($user->user_login) . '.json';
                file_put_contents($user_file, json_encode($user_data, JSON_PRETTY_PRINT));
            }
        }
        
        // Create ZIP archive
        $zip = new ZipArchive();
        $zip_file = get_temp_dir() . $filename;
        
        if ($zip->open($zip_file, ZipArchive::CREATE) === TRUE) {
            $files = new RecursiveIteratorIterator(
                new RecursiveDirectoryIterator($temp_dir),
                RecursiveIteratorIterator::LEAVES_ONLY
            );
            
            foreach ($files as $file) {
                if (!$file->isDir()) {
                    $zip->addFile(
                        $file->getRealPath(),
                        basename($file->getRealPath())
                    );
                }
            }
            
            $zip->close();
            
            // Send file to browser
            header('Content-Type: application/zip');
            header('Content-Disposition: attachment; filename="' . $filename . '"');
            header('Content-Length: ' . filesize($zip_file));
            readfile($zip_file);
            
            // Cleanup
            $this->cleanup_export_files($temp_dir, $zip_file);
            exit;
        }
        
        add_settings_error(
            'journal_users',
            'export_failed',
            __('Failed to create export archive', 'guided-journal')
        );
    }
    
    /**
     * Bulk delete users' journal data
     */
    private function bulk_delete_users_data($users) {
        global $wpdb;
        
        foreach ($users as $user_id) {
            // Backup data before deletion if enabled
            if (get_option('journal_backup_before_delete', true)) {
                $this->backup_user_data($user_id);
            }
            
            // Delete entries
            $wpdb->delete(
                $wpdb->prefix . 'journal_entries',
                array('user_id' => $user_id),
                array('%d')
            );
            
            // Delete progress
            $wpdb->delete(
                $wpdb->prefix . 'journal_user_progress',
                array('user_id' => $user_id),
                array('%d')
            );
            
            // Delete user meta
            delete_user_meta($user_id, 'journal_settings');
            delete_user_meta($user_id, 'journal_stats');
        }
        
        add_settings_error(
            'journal_users',
            'delete_success',
            __('Selected users\' journal data has been deleted', 'guided-journal'),
            'updated'
        );
    }
    
    /**
     * Bulk backup users' journal data
     */
    private function bulk_backup_users_data($users) {
        foreach ($users as $user_id) {
            $this->backup_user_data($user_id);
        }
        
        add_settings_error(
            'journal_users',
            'backup_success',
            __('Selected users\' journal data has been backed up', 'guided-journal'),
            'updated'
        );
    }
    
    /**
     * Get URL for viewing user entries
     */
    private function get_user_entries_url($user_id) {
        return add_query_arg(
            array(
                'page' => 'journal-entries',
                'user' => $user_id
            ),
            admin_url('admin.php')
        );
    }
    
    /**
     * Get URL for exporting user data
     */
    private function get_export_url($user_id) {
        return wp_nonce_url(
            add_query_arg(
                array(
                    'action' => 'export_journal',
                    'user' => $user_id
                ),
                admin_url('admin-ajax.php')
            ),
            'export_journal_' . $user_id
        );
    }
    
    /**
     * Get URL for deleting user data
     */
    private function get_delete_url($user_id) {
        return wp_nonce_url(
            add_query_arg(
                array(
                    'action' => 'delete_journal',
                    'user' => $user_id
                ),
                admin_url('admin-ajax.php')
            ),
            'delete_journal_' . $user_id
        );
    }
    
    /**
     * Add dashboard widgets
     */
    public function add_dashboard_widgets() {
        wp_add_dashboard_widget(
            'journal_stats_widget',
            __('Journal Statistics', 'guided-journal'),
            array($this, 'render_dashboard_widget')
        );
    }
    
    /**
     * Render dashboard widget
     */
    public function render_dashboard_widget() {
        $stats = $this->get_journal_statistics();
        ?>
        <div class="journal-dashboard-stats">
            <p>
                <strong><?php _e('Total Users:', 'guided-journal'); ?></strong>
                <?php echo esc_html($stats['total_users']); ?>
            </p>
            <p>
                <strong><?php _e('Total Entries:', 'guided-journal'); ?></strong>
                <?php echo esc_html($stats['total_entries']); ?>
            </p>
            <p>
                <strong><?php _e('Active Users (30 days):', 'guided-journal'); ?></strong>
                <?php echo esc_html($stats['active_users']); ?>
            </p>
            <p>
                <strong><?php _e('Average Completion Rate:', 'guided-journal'); ?></strong>
                <?php echo esc_html($stats['completion_rate']); ?>%
            </p>
        </div>
        <?php
    }
    
    /**
     * Get journal statistics
     */
    private function get_journal_statistics() {
        global $wpdb;
        
        $stats = array();
        
        // Total users with entries
        $stats['total_users'] = $wpdb->get_var("
            SELECT COUNT(DISTINCT user_id) 
            FROM {$wpdb->prefix}journal_entries
        ");
        
        // Total entries
        $stats['total_entries'] = $wpdb->get_var("
            SELECT COUNT(*) 
            FROM {$wpdb->prefix}journal_entries
        ");
        
        // Active users in last 30 days
        $stats['active_users'] = $wpdb->get_var($wpdb->prepare("
            SELECT COUNT(DISTINCT user_id)
            FROM {$wpdb->prefix}journal_entries
            WHERE created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)
        "));
        
        // Average completion rate
        $stats['completion_rate'] = $wpdb->get_var("
            SELECT ROUND(AVG(completed_days) * 100 / 30, 1)
            FROM {$wpdb->prefix}journal_user_progress
        ");
        
        // Top users
        $stats['top_users'] = $wpdb->get_results("
            SELECT 
                u.ID,
                u.display_name,
                COUNT(e.id) as total_entries,
                MAX(p.streak_count) as streak_count,
                MAX(e.created_at) as last_entry_date
            FROM {$wpdb->prefix}journal_entries e
            JOIN {$wpdb->users} u ON e.user_id = u.ID
            LEFT JOIN {$wpdb->prefix}journal_user_progress p ON e.user_id = p.user_id
            GROUP BY u.ID
            ORDER BY total_entries DESC
            LIMIT 10
        ");
        
        return $stats;
    }
    
    /**
     * Enqueue admin assets
     */
    public function enqueue_admin_assets($hook) {
        if (strpos($hook, 'journal') !== false) {
            wp_enqueue_style(
                'journal-admin-style',
                JOURNAL_PLUGIN_URL . 'assets/css/admin.css',
                array(),
                JOURNAL_PLUGIN_VERSION
            );
            
            wp_enqueue_script(
                'journal-admin-script',
                JOURNAL_PLUGIN_URL . 'assets/js/admin.js',
                array('jquery', 'chart.js'),
                JOURNAL_PLUGIN_VERSION,
                true
            );
            
            wp_localize_script('journal-admin-script', 'journalAdmin', array(
                'nonce' => wp_create_nonce('journal_admin'),
                'ajaxurl' => admin_url('admin-ajax.php'),
                'strings' => array(
                    'confirmDelete' => __('Are you sure you want to delete this data?', 'guided-journal'),
                    'deleteSuccess' => __('Data deleted successfully', 'guided-journal'),
                    'deleteFailed' => __('Failed to delete data', 'guided-journal'),
                    'testSuccess' => __('Circle connection successful', 'guided-journal'),
                    'testFailed' => __('Circle connection failed', 'guided-journal')
                )
            ));
        }
    }
}