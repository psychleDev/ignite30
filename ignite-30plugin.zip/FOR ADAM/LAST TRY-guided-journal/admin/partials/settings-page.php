<?php
/**
 * Admin Settings Page Template
 * 
 * Displays the admin interface for managing journal settings
 */

// Prevent direct access
<?php
if (!defined('ABSPATH')) exit;

class Journal_Database {
    private $wpdb;
    private $table_name;

    public function __construct() {
        global $wpdb;
        $this->wpdb = $wpdb;
        $this->table_name = $wpdb->prefix . 'journal_entries';
    }
}

<div class="wrap journal-settings-wrap">
    <h1><?php echo esc_html(get_admin_page_title()); ?></h1>

    <?php settings_errors(); ?>

    <nav class="nav-tab-wrapper">
        <a href="#general" class="nav-tab <?php echo $active_tab === 'general' ? 'nav-tab-active' : ''; ?>" data-tab="general">
            <?php _e('General Settings', 'guided-journal'); ?>
        </a>
        <a href="#circle" class="nav-tab <?php echo $active_tab === 'circle' ? 'nav-tab-active' : ''; ?>" data-tab="circle">
            <?php _e('Circle SSO', 'guided-journal'); ?>
        </a>
        <a href="#privacy" class="nav-tab <?php echo $active_tab === 'privacy' ? 'nav-tab-active' : ''; ?>" data-tab="privacy">
            <?php _e('Privacy', 'guided-journal'); ?>
        </a>
        <a href="#prompts" class="nav-tab <?php echo $active_tab === 'prompts' ? 'nav-tab-active' : ''; ?>" data-tab="prompts">
            <?php _e('Journal Prompts', 'guided-journal'); ?>
        </a>
        <a href="#backup" class="nav-tab <?php echo $active_tab === 'backup' ? 'nav-tab-active' : ''; ?>" data-tab="backup">
            <?php _e('Backup & Export', 'guided-journal'); ?>
        </a>
    </nav>

    <form method="post" action="options.php" id="journal-settings-form">
        <?php settings_fields('journal_settings_group'); ?>

        <!-- General Settings Tab -->
        <div id="general" class="tab-content <?php echo $active_tab === 'general' ? 'active' : ''; ?>">
            <h2><?php _e('General Settings', 'guided-journal'); ?></h2>
            
            <table class="form-table">
                <tr>
                    <th scope="row">
                        <label for="auto_save_interval">
                            <?php _e('Auto-save Interval', 'guided-journal'); ?>
                        </label>
                    </th>
                    <td>
                        <input type="number" 
                               id="auto_save_interval" 
                               name="journal_settings[auto_save_interval]" 
                               value="<?php echo esc_attr(get_option('journal_settings')['auto_save_interval'] ?? 60); ?>"
                               min="0"
                               max="300"
                               class="small-text">
                        <p class="description">
                            <?php _e('Interval in seconds between auto-saves (0 to disable)', 'guided-journal'); ?>
                        </p>
                    </td>
                </tr>

                <tr>
                    <th scope="row">
                        <label for="word_count_min">
                            <?php _e('Minimum Word Count', 'guided-journal'); ?>
                        </label>
                    </th>
                    <td>
                        <input type="number" 
                               id="word_count_min" 
                               name="journal_settings[word_count_min]" 
                               value="<?php echo esc_attr(get_option('journal_settings')['word_count_min'] ?? 0); ?>"
                               min="0"
                               class="small-text">
                        <p class="description">
                            <?php _e('Minimum required words per entry (0 for no limit)', 'guided-journal'); ?>
                        </p>
                    </td>
                </tr>

                <tr>
                    <th scope="row">
                        <label for="word_count_max">
                            <?php _e('Maximum Word Count', 'guided-journal'); ?>
                        </label>
                    </th>
                    <td>
                        <input type="number" 
                               id="word_count_max" 
                               name="journal_settings[word_count_max]" 
                               value="<?php echo esc_attr(get_option('journal_settings')['word_count_max'] ?? 0); ?>"
                               min="0"
                               class="small-text">
                        <p class="description">
                            <?php _e('Maximum allowed words per entry (0 for no limit)', 'guided-journal'); ?>
                        </p>
                    </td>
                </tr>

                <tr>
                    <th scope="row"><?php _e('Writing Tools', 'guided-journal'); ?></th>
                    <td>
                        <fieldset>
                            <legend class="screen-reader-text">
                                <?php _e('Writing Tools', 'guided-journal'); ?>
                            </legend>
                            <label>
                                <input type="checkbox" 
                                       name="journal_settings[enable_formatting]" 
                                       value="1"
                                       <?php checked(get_option('journal_settings')['enable_formatting'] ?? true); ?>>
                                <?php _e('Enable text formatting tools', 'guided-journal'); ?>
                            </label>
                            <br>
                            <label>
                                <input type="checkbox" 
                                       name="journal_settings[enable_markdown]" 
                                       value="1"
                                       <?php checked(get_option('journal_settings')['enable_markdown'] ?? true); ?>>
                                <?php _e('Enable Markdown support', 'guided-journal'); ?>
                            </label>
                        </fieldset>
                    </td>
                </tr>
            </table>
        </div>

        <!-- Circle SSO Tab -->
        <div id="circle" class="tab-content <?php echo $active_tab === 'circle' ? 'active' : ''; ?>">
            <h2><?php _e('Circle SSO Settings', 'guided-journal'); ?></h2>
            
            <table class="form-table">
                <tr>
                    <th scope="row">
                        <label for="circle_client_id">
                            <?php _e('Client ID', 'guided-journal'); ?>
                        </label>
                    </th>
                    <td>
                        <input type="text" 
                               id="circle_client_id" 
                               name="circle_client_id" 
                               value="<?php echo esc_attr(get_option('circle_client_id')); ?>"
                               class="regular-text">
                    </td>
                </tr>

                <tr>
                    <th scope="row">
                        <label for="circle_client_secret">
                            <?php _e('Client Secret', 'guided-journal'); ?>
                        </label>
                    </th>
                    <td>
                        <input type="password" 
                               id="circle_client_secret" 
                               name="circle_client_secret" 
                               value="<?php echo esc_attr(get_option('circle_client_secret')); ?>"
                               class="regular-text">
                    </td>
                </tr>

                <tr>
                    <th scope="row">
                        <label for="circle_community_url">
                            <?php _e('Community URL', 'guided-journal'); ?>
                        </label>
                    </th>
                    <td>
                        <input type="url" 
                               id="circle_community_url" 
                               name="circle_community_url" 
                               value="<?php echo esc_url(get_option('circle_community_url')); ?>"
                               class="regular-text">
                        <p class="description">
                            <?php _e('Your Circle Community URL (e.g., https://community.example.com)', 'guided-journal'); ?>
                        </p>
                    </td>
                </tr>
            </table>

            <p class="submit">
                <button type="button" id="test-circle-connection" class="button button-secondary">
                    <?php _e('Test Connection', 'guided-journal'); ?>
                </button>
                <span class="spinner"></span>
            </p>
            <div id="test-result"></div>
        </div>

        <!-- Privacy Tab -->
        <div id="privacy" class="tab-content <?php echo $active_tab === 'privacy' ? 'active' : ''; ?>">
            <h2><?php _e('Privacy Settings', 'guided-journal'); ?></h2>
            
            <table class="form-table">
                <tr>
                    <th scope="row"><?php _e('Entry Visibility', 'guided-journal'); ?></th>
                    <td>
                        <fieldset>
                            <legend class="screen-reader-text">
                                <?php _e('Entry Visibility', 'guided-journal'); ?>
                            </legend>
                            <label>
                                <input type="checkbox" 
                                       name="journal_settings[allow_public_entries]" 
                                       value="1"
                                       <?php checked(get_option('journal_settings')['allow_public_entries'] ?? true); ?>>
                                <?php _e('Allow public entries', 'guided-journal'); ?>
                            </label>
                            <br>
                            <label>
                                <input type="checkbox" 
                                       name="journal_settings[allow_community_entries]" 
                                       value="1"
                                       <?php checked(get_option('journal_settings')['allow_community_entries'] ?? true); ?>>
                                <?php _e('Allow community entries', 'guided-journal'); ?>
                            </label>
                        </fieldset>
                    </td>
                </tr>

                <tr>
                    <th scope="row"><?php _e('Data Protection', 'guided-journal'); ?></th>
                    <td>
                        <fieldset>
                            <legend class="screen-reader-text">
                                <?php _e('Data Protection', 'guided-journal'); ?>
                            </legend>
                            <label>
                                <input type="checkbox" 
                                       name="journal_settings[encryption_enabled]" 
                                       value="1"
                                       <?php checked(get_option('journal_settings')['encryption_enabled'] ?? true); ?>>
                                <?php _e('Enable encryption for private entries', 'guided-journal'); ?>
                            </label>
                            <br>
                            <label>
                                <input type="checkbox" 
                                       name="journal_settings[backup_entries]" 
                                       value="1"
                                       <?php checked(get_option('journal_settings')['backup_entries'] ?? true); ?>>
                                <?php _e('Enable automatic backups', 'guided-journal'); ?>
                            </label>
                        </fieldset>
                    </td>
                </tr>

                <tr>
                    <th scope="row">
                        <label for="data_retention">
                            <?php _e('Data Retention', 'guided-journal'); ?>
                        </label>
                    </th>
                    <td>
                        <select id="data_retention" name="journal_settings[data_retention]">
                            <option value="0" <?php selected(get_option('journal_settings')['data_retention'] ?? 0, 0); ?>>
                                <?php _e('Forever', 'guided-journal'); ?>
                            </option>
                            <option value="30" <?php selected(get_option('journal_settings')['data_retention'] ?? 0, 30); ?>>
                                <?php _e('30 days', 'guided-journal'); ?>
                            </option>
                            <option value="90" <?php selected(get_option('journal_settings')['data_retention'] ?? 0, 90); ?>>
                                <?php _e('90 days', 'guided-journal'); ?>
                            </option>
                            <option value="180" <?php selected(get_option('journal_settings')['data_retention'] ?? 0, 180); ?>>
                                <?php _e('180 days', 'guided-journal'); ?>
                            </option>
                            <option value="365" <?php selected(get_option('journal_settings')['data_retention'] ?? 0, 365); ?>>
                                <?php _e('1 year', 'guided-journal'); ?>
                            </option>
                        </select>
                        <p class="description">
                            <?php _e('How long to keep journal entries', 'guided-journal'); ?>
                        </p>
                    </td>
                </tr>
            </table>
        </div>

        <!-- Prompts Tab -->
        <div id="prompts" class="tab-content <?php echo $active_tab === 'prompts' ? 'active' : ''; ?>">
            <h2><?php _e('Journal Prompts', 'guided-journal'); ?></h2>
            
            <div class="prompts-list">
                <?php
                $prompts = get_option('journal_prompts', array());
                foreach ($prompts as $index => $prompt):
                ?>
                    <div class="prompt-field">
                        <span class="prompt-handle">↕️</span>
                        <input type="text" 
                               name="journal_prompts[]" 
                               value="<?php echo esc_attr($prompt); ?>"
                               class="regular-text">
                        <button type="button" class="remove-prompt">×</button>
                    </div>
                <?php endforeach; ?>
            </div>

            <p>
                <button type="button" id="add-prompt" class="button button-secondary">
                    <?php _e('Add Prompt', 'guided-journal'); ?>
                </button>
            </p>

            <input type="hidden" id="prompts_order" name="journal_prompts_order" value="">
        </div>

        <!-- Backup & Export Tab -->
        <div id="backup" class="tab-content <?php echo $active_tab === 'backup' ? 'active' : ''; ?>">
            <h2><?php _e('Backup & Export', 'guided-journal'); ?></h2>
            
            <table class="form-table">
                <tr>
                    <th scope="row"><?php _e('Settings Export/Import', 'guided-journal'); ?></th>
                    <td>
                        <button type="button" id="export-settings" class="button button-secondary">
                            <?php _e('Export Settings', 'guided-journal'); ?>
                        </button>
                        <input type="file" 
                               id="import-settings" 
                               accept=".json"
                               style="display: none;">
                        <button type="button" 
                                onclick="document.getElementById('import-settings').click()"
                                class="button button-secondary">
                            <?php _e('Import Settings', 'guided-journal'); ?>
                        </button>
                    </td>
                </tr>

                <tr>
                    <th scope="row"><?php _e('Backup Options', 'guided-journal'); ?></th>
                    <td>
                        <fieldset>
                            <legend class="screen-reader-text">
                                <?php _e('Backup Options', 'guided-journal'); ?>
                            </legend>
                            <label>
                                <input type="checkbox" 
                                       name="journal_settings[backup_before_delete]" 
                                       value="1"
                                       <?php checked(get_option('journal_settings')['backup_before_delete'] ?? true); ?>>
                                <?php _e('Create backup before deleting entries', 'guided-journal'); ?>
                            </label>

                            <br>
                            <label>
                                <input type="checkbox" 
                                       name="journal_settings[keep_backup_history]" 
                                       value="1"
                                       <?php checked(get_option('journal_settings')['keep_backup_history'] ?? true); ?>>
                                <?php _e('Keep backup history', 'guided-journal'); ?>
                            </label>
                        </fieldset>
                    </td>
                </tr>

                <tr>
                    <th scope="row">
                        <label for="backup_retention">
                            <?php _e('Backup Retention', 'guided-journal'); ?>
                        </label>
                    </th>
                    <td>
                        <select id="backup_retention" name="journal_settings[backup_retention]">
                            <option value="7" <?php selected(get_option('journal_settings')['backup_retention'] ?? 7, 7); ?>>
                                <?php _e('7 days', 'guided-journal'); ?>
                            </option>
                            <option value="14" <?php selected(get_option('journal_settings')['backup_retention'] ?? 7, 14); ?>>
                                <?php _e('14 days', 'guided-journal'); ?>
                            </option>
                            <option value="30" <?php selected(get_option('journal_settings')['backup_retention'] ?? 7, 30); ?>>
                                <?php _e('30 days', 'guided-journal'); ?>
                            </option>
                            <option value="90" <?php selected(get_option('journal_settings')['backup_retention'] ?? 7, 90); ?>>
                                <?php _e('90 days', 'guided-journal'); ?>
                            </option>
                        </select>
                        <p class="description">
                            <?php _e('How long to keep backup files', 'guided-journal'); ?>
                        </p>
                    </td>
                </tr>

                <tr>
                    <th scope="row">
                        <label for="backup_location">
                            <?php _e('Backup Location', 'guided-journal'); ?>
                        </label>
                    </th>
                    <td>
                        <input type="text" 
                               id="backup_location" 
                               name="journal_settings[backup_location]" 
                               value="<?php echo esc_attr(get_option('journal_settings')['backup_location'] ?? WP_CONTENT_DIR . '/backups/journal'); ?>"
                               class="regular-text">
                        <p class="description">
                            <?php _e('Full path to backup directory', 'guided-journal'); ?>
                        </p>
                    </td>
                </tr>
            </table>

            <div class="backup-actions">
                <h3><?php _e('Manual Backup', 'guided-journal'); ?></h3>
                <p>
                    <button type="button" id="create-backup" class="button button-primary">
                        <?php _e('Create Backup Now', 'guided-journal'); ?>
                    </button>
                    <span class="spinner"></span>
                </p>

                <h3><?php _e('Recent Backups', 'guided-journal'); ?></h3>
                <table class="widefat backup-history">
                    <thead>
                        <tr>
                            <th><?php _e('Date', 'guided-journal'); ?></th>
                            <th><?php _e('Size', 'guided-journal'); ?></th>
                            <th><?php _e('Type', 'guided-journal'); ?></th>
                            <th><?php _e('Actions', 'guided-journal'); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $backups = Journal_Admin::get_recent_backups();
                        if (empty($backups)):
                        ?>
                            <tr>
                                <td colspan="4"><?php _e('No backups found', 'guided-journal'); ?></td>
                            </tr>
                        <?php else: ?>
                            <?php foreach ($backups as $backup): ?>
                                <tr>
                                    <td><?php echo esc_html($backup['date']); ?></td>
                                    <td><?php echo esc_html($backup['size']); ?></td>
                                    <td><?php echo esc_html($backup['type']); ?></td>
                                    <td>
                                        <a href="<?php echo esc_url($backup['download_url']); ?>" 
                                           class="button button-small">
                                            <?php _e('Download', 'guided-journal'); ?>
                                        </a>
                                        <button type="button" 
                                                class="button button-small delete-backup" 
                                                data-backup="<?php echo esc_attr($backup['id']); ?>">
                                            <?php _e('Delete', 'guided-journal'); ?>
                                        </button>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>

        <!-- Uninstall Options -->
        <div class="uninstall-options">
            <h3><?php _e('Uninstall Options', 'guided-journal'); ?></h3>
            <table class="form-table">
                <tr>
                    <th scope="row"><?php _e('Data Cleanup', 'guided-journal'); ?></th>
                    <td>
                        <fieldset>
                            <legend class="screen-reader-text">
                                <?php _e('Data Cleanup', 'guided-journal'); ?>
                            </legend>
                            <label>
                                <input type="checkbox" 
                                       name="journal_settings[delete_data_on_uninstall]" 
                                       value="1"
                                       <?php checked(get_option('journal_settings')['delete_data_on_uninstall'] ?? false); ?>>
                                <?php _e('Delete all data when uninstalling the plugin', 'guided-journal'); ?>
                            </label>
                            <p class="description">
                                <?php _e('Warning: This will permanently delete all journal entries and settings', 'guided-journal'); ?>
                            </p>
                        </fieldset>
                    </td>
                </tr>
            </table>
        </div>

        <?php submit_button(); ?>
    </form>

    <!-- Support Information -->
    <div class="journal-support-info">
        <h3><?php _e('Support Information', 'guided-journal'); ?></h3>
        <div class="support-content">
            <p>
                <?php _e('Need help? Check out our documentation or contact support:', 'guided-journal'); ?>
            </p>
            <ul>
                <li>
                    <a href="https://docs.example.com/journal" target="_blank">
                        <?php _e('Documentation', 'guided-journal'); ?>
                    </a>
                </li>
                <li>
                    <a href="https://example.com/support" target="_blank">
                        <?php _e('Support Portal', 'guided-journal'); ?>
                    </a>
                </li>
                <li>
                    <a href="mailto:support@example.com">
                        <?php _e('Email Support', 'guided-journal'); ?>
                    </a>
                </li>
            </ul>
            <div class="system-info">
                <h4><?php _e('System Information', 'guided-journal'); ?></h4>
                <textarea readonly class="large-text code" rows="10">
<?php Journal_Admin::get_system_info(); ?>
                </textarea>
            </div>
        </div>
    </div>
</div>