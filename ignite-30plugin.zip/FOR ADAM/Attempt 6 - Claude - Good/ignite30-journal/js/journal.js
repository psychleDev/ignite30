document.addEventListener('DOMContentLoaded', () => {
    class Journal {
        constructor() {
            this.JOURNAL_PROMPTS = [
                "Gratitude Reflection: What are you most grateful for today and why?",
                "Emotional Landscape: Describe a moment that deeply moved you recently.",
                "Personal Challenge: What obstacle have you recently overcome?",
                "Strength Exploration: What personal strength are you most proud of?",
                "Learning Journey: What new skill or knowledge have you acquired this week?",
                "Dream Visualization: Describe your ideal day from start to finish.",
                "Goal Setting: What are your top three personal or professional goals?",
                "Relationship Insight: Reflect on a meaningful relationship in your life.",
                "Inner Peace: What activities or practices bring you true tranquility?",
                "Aspiration Mapping: Describe a dream or long-term aspiration in detail.",
                "Confronting Fears: What have you been avoiding, and why?",
                "Memory Lane: Recall and describe a pivotal childhood memory.",
                "Self-Care Exploration: What does genuine self-care look like for you?",
                "Growth Moment: Describe a recent experience that caused personal growth.",
                "Future Anticipation: What are you most looking forward to?",
                "Success Celebration: Reflect on a recent personal or professional success.",
                "Wisdom Transfer: What advice would you give to your younger self?",
                "Sanctuary Visualization: Describe a place that brings you complete calm.",
                "Curiosity Spark: What are you currently most curious about?",
                "Value Alignment: Write about a personal value that guides your decisions.",
                "Kindness Reflection: Describe a recent act of kindness you experienced.",
                "Motivation Exploration: What truly motivates you in life?",
                "Lesson Learned: Reflect on a significant life lesson.",
                "Unique Identity: What makes you uniquely you?",
                "Skill Development: What skill would you like to develop, and why?",
                "Joy Inventory: List and describe what genuinely brings you joy.",
                "Fear Confrontation: Identify a fear you want to overcome.",
                "Happiness Definition: What does happiness truly mean to you?",
                "Personal Progress: Reflect on how you've grown over the past year.",
                "Future Vision: Describe your hopes and vision for your future self."
            ];

            this.initializeElements();
            this.addEventListeners();
            this.setupGrid();
        }

        initializeElements() {
            this.promptGrid = document.getElementById('promptGrid');
            this.journalEntry = document.getElementById('journalEntry');
            this.dayTitle = document.getElementById('dayTitle');
            this.promptText = document.getElementById('promptText');
            this.entryField = document.getElementById('entryField');
            this.saveBtn = document.getElementById('saveBtn');
            this.prevBtn = document.getElementById('prevBtn');
            this.nextBtn = document.getElementById('nextBtn');
            this.listToggle = document.getElementById('listToggle');
            this.entriesList = document.getElementById('entriesList');
            
            this.currentDay = 1;
        }

        addEventListeners() {
            if (this.saveBtn) {
                this.saveBtn.addEventListener('click', () => this.saveEntry());
            }
            if (this.prevBtn) {
                this.prevBtn.addEventListener('click', () => this.navigateDay('prev'));
            }
            if (this.nextBtn) {
                this.nextBtn.addEventListener('click', () => this.navigateDay('next'));
            }
            if (this.listToggle) {
                this.listToggle.addEventListener('click', () => this.toggleEntries());
            }
        }

        setupGrid() {
            this.promptGrid.innerHTML = '';
            for (let i = 1; i <= 30; i++) {
                const dayCard = document.createElement('div');
                dayCard.className = 'prompt-card';
                dayCard.innerHTML = `<div class="day-number">DAY ${i}</div>`;
                dayCard.addEventListener('click', () => this.loadDay(i));
                this.promptGrid.appendChild(dayCard);
            }
        }

        async loadDay(day) {
            this.currentDay = day;
            this.journalEntry.style.display = 'block';
            this.dayTitle.textContent = `Day ${day}`;
            this.promptText.textContent = this.JOURNAL_PROMPTS[day - 1];
            
            try {
                const response = await fetch(`${ignite30_ajax.ajax_url}?action=ignite30_get_entry&day=${day}&security=${ignite30_ajax.nonce}`);
                const data = await response.json();
                
                if (data.success && data.entry) {
                    this.entryField.value = data.entry.entry_content || '';
                } else {
                    this.entryField.value = '';
                }

                this.updateNavButtons();
            } catch (error) {
                console.error('Error loading entry:', error);
            }
        }

        async saveEntry() {
            if (!this.entryField.value.trim()) return;

            try {
                const response = await fetch(ignite30_ajax.ajax_url, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded'
                    },
                    body: new URLSearchParams({
                        action: 'ignite30_save_entry',
                        security: ignite30_ajax.nonce,
                        day: this.currentDay,
                        content: this.entryField.value
                    })
                });

                const data = await response.json();
                if (data.success) {
                    this.showNotification('Entry saved successfully!');
                    if (this.entriesList.classList.contains('active')) {
                        this.loadEntries();
                    }
                } else {
                    this.showNotification('Error saving entry.', 'error');
                }
            } catch (error) {
                console.error('Error saving entry:', error);
                this.showNotification('Error saving entry.', 'error');
            }
        }

        navigateDay(direction) {
            const newDay = direction === 'prev' ? 
                Math.max(1, this.currentDay - 1) : 
                Math.min(30, this.currentDay + 1);
                
            if (newDay !== this.currentDay) {
                this.loadDay(newDay);
            }
        }

        updateNavButtons() {
            if (this.prevBtn) this.prevBtn.disabled = this.currentDay === 1;
            if (this.nextBtn) this.nextBtn.disabled = this.currentDay === 30;
        }

        async toggleEntries() {
            this.entriesList.classList.toggle('active');
            
            if (this.entriesList.classList.contains('active')) {
                await this.loadEntries();
                this.listToggle.textContent = 'Hide Entries';
            } else {
                this.listToggle.textContent = 'View All Entries';
            }
        }

        async loadEntries() {
            try {
                const response = await fetch(`${ignite30_ajax.ajax_url}?action=ignite30_get_all_entries&security=${ignite30_ajax.nonce}`);
                const data = await response.json();
                
                if (data.success) {
                    this.displayEntries(data.entries);
                }
            } catch (error) {
                console.error('Error loading entries:', error);
            }
        }

        displayEntries(entries) {
            this.entriesList.innerHTML = '';
            
            for (let i = 1; i <= 30; i++) {
                const entry = entries.find(e => parseInt(e.day_number) === i);
                const entryItem = document.createElement('div');
                entryItem.className = 'entry-item';
                
                entryItem.innerHTML = `
                    <span>DAY ${i}</span>
                    <span class="entry-status">${entry ? 'COMPLETED' : 'NOT STARTED'}</span>
                `;
                
                entryItem.addEventListener('click', () => this.loadDay(i));
                this.entriesList.appendChild(entryItem);
            }
        }

        showNotification(message, type = 'success') {
            const notification = document.createElement('div');
            notification.className = `journal-notification ${type}`;
            notification.textContent = message;
            document.body.appendChild(notification);
            
            setTimeout(() => {
                notification.remove();
            }, 3000);
        }
    }

    // Initialize the journal if we're on a journal page
    if (document.getElementById('ignite30-app')) {
        new Journal();
    }
});
