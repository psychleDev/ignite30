<?php
if (!defined('ABSPATH')) exit;

class Ignite30_Admin_Settings {
    public function __construct() {
        add_action('admin_menu', array($this, 'add_admin_menu'));
        add_action('admin_init', array($this, 'init_settings'));
    }

    public function add_admin_menu() {
        add_menu_page(
            'Ignite 30 Journal Settings',
            'Ignite 30 Journal',
            'manage_options',
            'ignite30-journal',
            array($this, 'render_settings_page'),
            'dashicons-book-alt'
        );
    }

    public function init_settings() {
        register_setting('ignite30_settings', 'ignite30_mode');
        register_setting('ignite30_settings', 'ignite30_circle_space_url');
        register_setting('ignite30_settings', 'ignite30_circle_api_key');

        add_settings_section(
            'ignite30_main_section',
            'Journal Settings',
            array($this, 'section_callback'),
            'ignite30_settings'
        );

        add_settings_field(
            'ignite30_mode',
            'Operation Mode',
            array($this, 'mode_callback'),
            'ignite30_settings',
            'ignite30_main_section'
        );

        add_settings_field(
            'ignite30_circle_space_url',
            'Circle Space URL',
            array($this, 'circle_url_callback'),
            'ignite30_settings',
            'ignite30_main_section'
        );

        add_settings_field(
            'ignite30_circle_api_key',
            'Circle API Key',
            array($this, 'circle_api_callback'),
            'ignite30_settings',
            'ignite30_main_section'
        );
    }

    public function section_callback() {
        echo '<p>Configure your journal settings below:</p>';
    }

    public function mode_callback() {
        $mode = get_option('ignite30_mode', 'test');
        ?>
        <select name="ignite30_mode">
            <option value="test" <?php selected($mode, 'test'); ?>>Test Mode</option>
            <option value="production" <?php selected($mode, 'production'); ?>>Production Mode</option>
        </select>
        <p class="description">Test mode bypasses Circle SSO for development purposes.</p>
        <?php
    }

    public function circle_url_callback() {
        $url = get_option('ignite30_circle_space_url');
        ?>
        <input type="url" class="regular-text" name="ignite30_circle_space_url" 
            value="<?php echo esc_attr($url); ?>" />
        <p class="description">Your Circle community URL (e.g., https://community.risingfather.com)</p>
        <?php
    }

    public function circle_api_callback() {
        $key = get_option('ignite30_circle_api_key');
        ?>
        <input type="password" class="regular-text" name="ignite30_circle_api_key" 
            value="<?php echo esc_attr($key); ?>" />
        <p class="description">Your Circle API key for authentication</p>
        <?php
    }

    public function render_settings_page() {
        ?>
        <div class="wrap">
            <h1>Ignite 30 Journal Settings</h1>
            <form method="post" action="options.php">
                <?php
                settings_fields('ignite30_settings');
                do_settings_sections('ignite30_settings');
                submit_button();
                ?>
            </form>
        </div>
        <?php
    }
}
