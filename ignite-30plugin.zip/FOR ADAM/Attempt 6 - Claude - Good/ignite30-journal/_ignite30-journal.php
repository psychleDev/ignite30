<?php
/*
Plugin Name: Ignite 30 Journal
Description: A 30-day guided journal with Circle SSO integration
Version: 1.0
Author: Rising Father
Author URI: https://risingfather.com
*/

if (!defined('ABSPATH')) exit;

class Ignite30Journal {
    private $table_name;

    public function __construct() {
        global $wpdb;
        $this->table_name = $wpdb->prefix . 'ignite30_entries';
        
        // Basic functionality
        add_action('wp_enqueue_scripts', array($this, 'enqueue_scripts'));
        add_action('admin_menu', array($this, 'add_admin_menu'));
        add_action('admin_init', array($this, 'register_settings'));
        add_shortcode('ignite30_journal', array($this, 'render_journal'));
        
        // Activation hook
        register_activation_hook(__FILE__, array($this, 'activate_plugin'));
    }

    public function activate_plugin() {
        $this->create_database_table();
        add_option('ignite30_mode', 'test');
        add_option('ignite30_circle_space_url', '');
    }

    private function create_database_table() {
        global $wpdb;
        $charset_collate = $wpdb->get_charset_collate();
        
        $sql = "CREATE TABLE IF NOT EXISTS $this->table_name (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            user_id bigint(20) NOT NULL,
            day_number int(11) NOT NULL,
            entry_content longtext NOT NULL,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            updated_at datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY user_day (user_id, day_number)
        ) $charset_collate;";
        
        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($sql);
    }

    public function enqueue_scripts() {
        if (has_shortcode(get_the_content(), 'ignite30_journal')) {
            wp_enqueue_style(
                'ignite30-theme-style',
                get_template_directory_uri() . '/assets/css/main.css'
            );
            
            wp_enqueue_script(
                'ignite30-journal',
                plugins_url('js/journal.js', __FILE__),
                array('jquery'),
                '1.0',
                true
            );

            wp_localize_script('ignite30-journal', 'ignite30_ajax', array(
                'ajax_url' => admin_url('admin-ajax.php'),
                'nonce' => wp_create_nonce('ignite30_nonce')
            ));
        }
    }

    // Admin Settings
    public function add_admin_menu() {
        add_options_page(
            'Ignite 30 Journal Settings',
            'Ignite 30 Journal',
            'manage_options',
            'ignite30-journal',
            array($this, 'render_settings_page')
        );
    }

    public function register_settings() {
        register_setting('ignite30_settings', 'ignite30_mode');
        register_setting('ignite30_settings', 'ignite30_circle_space_url');
    }

    public function render_settings_page() {
        ?>
        <div class="wrap">
            <h1>Ignite 30 Journal Settings</h1>
            <form method="post" action="options.php">
                <?php
                settings_fields('ignite30_settings');
                ?>
                <table class="form-table">
                    <tr>
                        <th scope="row">Mode</th>
                        <td>
                            <select name="ignite30_mode">
                                <option value="test" <?php selected(get_option('ignite30_mode'), 'test'); ?>>Test Mode</option>
                                <option value="production" <?php selected(get_option('ignite30_mode'), 'production'); ?>>Production</option>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">Circle Space URL</th>
                        <td>
                            <input type="url" class="regular-text" name="ignite30_circle_space_url" 
                                value="<?php echo esc_attr(get_option('ignite30_circle_space_url')); ?>" />
                        </td>
                    </tr>
                </table>
                <?php submit_button(); ?>
            </form>
        </div>
        <?php
    }

    public function render_journal($atts) {
        ob_start();
        ?>
        <div id="ignite30-app">
            <div id="promptGrid" class="prompt-grid"></div>
            <div id="journalEntry" style="display: none;">
                <h2 id="dayTitle"></h2>
                <div id="promptText" class="prompt"></div>
                <textarea id="entryField" placeholder="Write your journal entry here..."></textarea>
                <div class="navigation">
                    <button id="prevBtn">Previous Day</button>
                    <button id="saveBtn">Save Entry</button>
                    <button id="nextBtn">Next Day</button>
                </div>
                <div class="view-entries">
                    <button id="listToggle" class="list-toggle">View All Entries</button>
                </div>
            </div>
            <div id="entriesList" class="entries-list"></div>
        </div>
        <?php
        return ob_get_clean();
    }
}

new Ignite30Journal();
